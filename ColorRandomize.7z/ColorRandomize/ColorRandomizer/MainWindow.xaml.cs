﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Reflection;
using System.Threading;

namespace ColorRandomizer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Brush[] m_BrushesArray;
        private int m_ColorsNumber = 0;
        Random rand = new Random();

        public MainWindow()
        {
            InitializeComponent();
            InitializeBrushArray();
        }

        private void InitializeBrushArray()
        {
            PropertyInfo[] properties = typeof(System.Windows.Media.Brushes)
                .GetProperties(BindingFlags.Static | BindingFlags.Public);

            m_ColorsNumber = properties.Count();
            m_BrushesArray = new Brush[m_ColorsNumber];

            for (int i = 0; i < m_ColorsNumber; i++)
            {
                m_BrushesArray[i] = (System.Windows.Media.Brush)properties[i]
                    .GetValue(null, null);
            }
        }

        private Brush GetRandomColor()
        {
            return m_BrushesArray[rand.Next(m_ColorsNumber)];
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Background = GetRandomColor();
        }
    }

}
