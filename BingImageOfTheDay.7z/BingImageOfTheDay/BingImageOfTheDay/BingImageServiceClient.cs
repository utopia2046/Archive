﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BingImageOfTheDay
{
    class BingImageServiceClient
    {
        const string bingImageServiceUrl = @"http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt={0}";

        string[] marketStrings = {
            "en-IE",
            "ar-AE",
            "es-AR",
            "it-IT",
            "en-IN",
            "en-ID",
            "ar-EG",
            "en-AU",
            "de-AT",
            "nl-NL",
            "fr-CA",
            "en-CA",
            "ar-SA",
            "en-SG",
            "de-CH",
            "fr-CH",
            "sv-SE",
            "es-ES",
            "es-CL",
            "da-DK",
            "de-DE",
            "tr-TR",
            "en-NZ",
            "nb-NO",
            "en-PH",
            "fi-FI",
            "pt-BR",
            "fr-FR",
            "nl-BE",
            "fr-BE",
            "pl-PL",
            "pt-PT",
            "es-MX",
            "ru-RU",
            "en-GB",
            "ko-KR",
            "zh-HK",
            "zh-TW",
            "zh-CN",
            "en-ZA",
            "ja-JP",
            "es-US",
            "en-US"
        };

        private async Task<string> GetImageInfoJson(string market)
        {
            string strBingImageURL = string.Format(bingImageServiceUrl, market);
            HttpClient client = new HttpClient();

            // Using an Async call makes sure the app is responsive during the time the response is fetched.
            // GetAsync sends an Async GET request to the Specified URI.
            HttpResponseMessage response = await client.GetAsync(new Uri(strBingImageURL));

            // Content property get or sets the content of a HTTP response message. 
            // ReadAsStringAsync is a method of the HttpContent which asynchronously 
            // reads the content of the HTTP Response and returns as a string.
            return await response.Content.ReadAsStringAsync();
        }

        private string GetImageUrlFromJson(string json)
        {
            // Parse using LINQ-to-JSON API's JObject explicitly.
            JObject jResults = JObject.Parse(json);

            return (string)jResults["images"].FirstOrDefault()["url"];
        }
    }
}
