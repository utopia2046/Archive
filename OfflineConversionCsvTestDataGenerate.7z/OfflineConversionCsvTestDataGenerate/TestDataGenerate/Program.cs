﻿using System;
using System.IO;

namespace TestDataGenerate
{
    class Program
    {
        static Random r;
        static void Main(string[] args)
        {
            const string name = "OfflineTest001";
            const int count = 100 * 1024; // 100k
            string clickId, time, val, record;
            r = new Random();

            using (StreamWriter sw = File.CreateText("100K.csv"))
            {
                sw.Write(TemplateHeader);
                sw.WriteLine(GenerateParameters());
                for (int i = 0; i < count; i++)
                {
                    clickId = GenerateClickId();
                    time = GetRandomDateString();
                    val = GetRandomDoubleString();
                    record = GenerateRecord(clickId, name, time, val);
                    sw.WriteLine(record);
                }
            }
        }

        static string GenerateClickId()
        {
            return Guid.NewGuid().ToString("N");
        }

        static string GenerateParameters(string timezone = "BogotaLimaQuito")
        {
            return $"Parameters:TimeZone={timezone},,,,";
        }

        static string GenerateRecord(string clickId, string conversionName, string dateString, string valueString, string currency = "USD")
        {
            return $"{clickId},\"{conversionName}\",\"{dateString}\",{valueString},{currency}";
        }

        static string GetRandomString(int minLen = 1, int maxLen = 16)
        {
            const string charset = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890 -_=+()";
            Random r = new Random();
            int length = r.Next(minLen, maxLen);
            char[] chars = new char[length];
            for (var i = 0; i < length; i++)
            {
                int index = r.Next(0, charset.Length);
                chars[i] = charset[index];
            }

            return new string(chars);
        }

        static string GetRandomDateString(string format = "yyyy-MM-dd HH:mm:ss")
        {
            var range = TimeSpan.FromDays(-90).TotalSeconds;
            DateTime time = DateTime.Now.AddSeconds(r.NextDouble() * range);
            return time.ToUniversalTime().ToString(format);
        }

        static string GetRandomDoubleString(double min = 0, double max = 1000, string format = "F2")
        {
            double val = r.NextDouble() * (max - min) + min;
            return val.ToString(format);
        }

        static string TemplateHeader
        {
            get
            {
                return @"### INSTRUCTIONS ###,,,,
""# Important: Remember to change the TimeZone value (GMT offset) in the """"parameters"""" row"",,,,
""# TimeZone values should be entered in HHMM format (e.g. New York is -0500, Berlin's is +0100 etc. If you use Greenwich Mean Time, then simply enter +0000.)"",,,,
""# Make sure you do not include additional columns. For more instructions on how to use this tempate, visit [BINGADSHELPARTICLE_whenready]"",,,,
,,,,
### TEMPLATE ###,,,,";
            }
        }
    }
}
