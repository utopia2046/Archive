﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace YyetsLinkGrabber
{
    class Program
    {
        static void Main(string[] args)
        {
            string testFile = "XMLFile1.xml";
            List<VideoDownloadInfo> videoList;
            try
            {
                var root = XElement.Load(testFile);
                videoList = ResodListParser.ParseResodList(root);
            }
            catch (Exception ex)
            {
                Trace.TraceError("Error when parsing xml. Exception: {0}", ex.ToString());
                return;
            }

            using (var sw = new StreamWriter("result.csv", false, Encoding.UTF8))
            {
                sw.WriteLine("Season,Episode,Format,FileName,FileSize,Link");
                foreach (var vi in videoList)
                {
                    var sb = new StringBuilder();
                    sb.AppendFormat("{0},{1},{2}", vi.Season, vi.Episode, vi.Format);
                    sb.AppendFormat(@",""{0}"",{1},""{2}""", vi.FileName, vi.FileSize, vi.DownloadLinks.FirstOrDefault().Value);
                    sw.WriteLine(sb.ToString());
                }
            }
        }
    }
}
