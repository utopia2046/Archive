﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace YyetsLinkGrabber
{
    public class ResodListParser
    {
        /// <summary>
        /// Find the div class="box_1" in document and pass it in, this function will try parse all episode info and return a List<VideoDownloadInfo>
        /// </summary>
        /// <param name="box_1">XElement of &lt;div class="box_1"&gt;</param>
        /// <returns>List of all episodes</returns>
        public static List<VideoDownloadInfo> ParseResodList(XElement box_1)
        {
            if ((box_1.Name != "div") || (box_1.Attribute("class").Value != "box_1"))
            {
                Trace.Fail("Input papameter is not a box_1 class div");
                return null;
            }
            List<VideoDownloadInfo> videoInfoList = new List<VideoDownloadInfo>();
            var qSeason = from s in box_1.Elements("ul") select s;
            foreach (var xeSeason in qSeason)
            {
                string season = xeSeason.Attribute("season").Value;
                Trace.TraceInformation("Season = {0}", season);
                var qEpisode = from e in xeSeason.Elements("li") select e;
                foreach (var xeEpisode in qEpisode)
                {
                    var videoInfo = new VideoDownloadInfo() { Season = season };
                    videoInfo.Episode = xeEpisode.Attribute("episode").Value;
                    Trace.TraceInformation("  Episode = {0}", videoInfo.Episode);
                    videoInfo.ItemId = xeEpisode.Attribute("itemid").Value;
                    videoInfo.Format = xeEpisode.Attribute("format").Value;
                    Trace.TraceInformation("  Format = {0}", videoInfo.Format);

                    var qFileName = (from xeSpan in xeEpisode.Descendants("span")
                        where xeSpan.Attribute("class").Value == "a" select xeSpan).FirstOrDefault();
                    videoInfo.FileName = (qFileName != null) ? qFileName.Value : String.Empty;
                    Trace.TraceInformation("  FileName = {0}", videoInfo.FileName);

                    var qFileSize = (from xeFont in xeEpisode.Descendants("font")
                        where (xeFont.Attribute("class") != null) && (xeFont.Attribute("class").Value == "f5")
                        select xeFont).FirstOrDefault();
                    videoInfo.FileSize = (qFileSize != null) ? qFileSize.Value : String.Empty;
                    Trace.TraceInformation("  FileSize = {0}", videoInfo.FileSize);

                    videoInfo.DownloadLinks = new Dictionary<DownloadType, string>();
                    var qUrl = (from xeA in xeEpisode.Descendants("a") where xeA.Value.Contains("迅雷")
                        select xeA).FirstOrDefault();
                    string url = (qUrl != null) ? qUrl.Attribute("umsfwwfk").Value : String.Empty;
                    videoInfo.DownloadLinks.Add(DownloadType.thunder, url);
                    Trace.TraceInformation("  Thunder download link = {0}", url);
                    videoInfoList.Add(videoInfo);
                }
            }
            return videoInfoList;
        }
    }
}
