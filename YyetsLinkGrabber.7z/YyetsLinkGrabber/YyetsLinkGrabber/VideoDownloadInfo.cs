﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YyetsLinkGrabber
{
    public class VideoDownloadInfo
    {
        public string BaseName { get; set; }
        public string FileName { get; set; }
        public string Season { get; set; }
        public string Episode { get; set; }
        public string ItemId { get; set; }
        public string Format { get; set; }
        public string FileSize { get; set; }
        public Dictionary<DownloadType, string> DownloadLinks { get; set; }
        public Dictionary<ViewerType, string> OnlineViewerLinks { get; set; }
    }

    public enum DownloadType
    {
        ed2k,
        magnet,
        thunder,
        qh,
        nofollow,
        urlxf,
        kuai,
        tv002,
        xiaomi,
    }

    public enum ViewerType
    {
        letv,
        sohu,
        qq,
    }
}
