/*global LiveUnit, QUnit*/
(function () {
    "use strict";
    // This portion of Qunit adapter has to be placed before the qunit.js file, so that it will remove the window onload event

    var originalWindowAttachEvent;
    var failedMessages;
    var finalResult;
    var qunitWindowOnloadHandler;

    if (window.addEventListener) {
        originalWindowAttachEvent = window.addEventListener;
        window.addEventListener = function (eventType, eventfunction, isCapturingPhase) {
            if (eventType === "load") {
                //TODO: Push the event handlers onto an array in case more than one event is registered
                qunitWindowOnloadHandler = eventfunction;
            }
            else {
                originalWindowAttachEvent(eventType, eventfunction, isCapturingPhase);
            }
        };
    }
    else if (window.attachEvent) {
        originalWindowAttachEvent = window.attachEvent;
        window.attachEvent = function (eventType, eventfunction) {
            if (eventType === "onload") {
                //TODO: Push the event handlers onto an array in case more than one event is registered
                qunitWindowOnloadHandler = eventfunction;
            }
            else {
                originalWindowAttachEvent(eventType, eventfunction);
            }
        };
    }

    window.runQunitTestCases = function (signalTestCaseCompleted) {
        function OutputResultCallBack() {
            if (finalResult.failed !== 0) {
                LiveUnit.Assert.isTrue(false, "Total " + finalResult.total + " test cases. " + finalResult.failed + " failed and " + finalResult.passed + " passed.");
            }
            else {
                LiveUnit.LoggingCore.logComment("Total " + finalResult.total + " test cases. " + finalResult.passed + " passed.");
                LiveUnit.Assert.isTrue(true);
                signalTestCaseCompleted();
            }
        }

        if (typeof qunitWindowOnloadHandler === "function") {
            qunitWindowOnloadHandler();
        }

        if (!document.getElementById("qunit-fixture")) {
            var qunitFixture = document.createElement("div");
            qunitFixture.id = "qunit-fixture";
            document.body.appendChild(qunitFixture);
        }
        // always wrap your callbacks so you get correct exception handling
        var liveUnitWrappedCallback = LiveUnit.GetWrappedCallback(OutputResultCallBack);

        QUnit.testStart = function () {
            failedMessages = [];
        };

        QUnit.log = function (result) {
            if (result.result !== true) {
                failedMessages.push(result);
            }
        };

        function extractFileInfo(msg) {
            /// <summary>
            /// Tries to extract file name, line and column from given message.
            /// E.g., when msg = "Error in (http://liveunit/url/file.js:15:2)" then the function will return
            ///     { fileName: "file.js", line: "15", column: "2" }
            /// When msg = "Exception occured in (http://liveunit/url/file.js)" then the function will return
            ///     { fileName: "file.js" }
            /// If msg = "Error: Ormma is undefined" then the function will return null.
            /// </summary>
            /// <param name="msg" type='String'>Message to parse.</param>
            /// <return type="Object">Parsed data, or null if failed to get any data.</return>

            if (typeof msg !== "string") {
                return null;
            }

            var a = msg.indexOf(")");
            if (a < 0) {
                return null;
            }

            var b = msg.lastIndexOf("/", a);
            if (b < 0) {
                return null;
            }

            var file = msg.substring(b + 1, a);
            a = file.indexOf(":");
            if (a < 0) {
                return {
                    fileName: file
                };
            }

            var line = file.substring(a + 1);
            file = file.substring(0, a);
            a = line.indexOf(":");
            if (a < 0) {
                return {
                    fileName: file,
                    line: line
                };
            }

            var column = line.substring(a + 1);
            line = line.substring(0, a);

            return {
                fileName: file,
                line: line,
                column: column
            };
        }

        function logError(comment, file, line, column) {
            /// <summary>
            /// Logs error in a standard MSBuild format.
            /// </summary>
            /// <param name="comment" type='String'>Comment to log.</param>
            /// <param name="file" type='String'>File where the error occured. Optional.</param>
            /// <param name="line" type='String'>Line where the error occured. Optional.</param>
            /// <param name="column" type='String'>Column where the error occured. Optional.</param>

            // The below condition is the same as in LiveUnit
            if (window.external && window.external.ToString != null) {
                var msg = "";
                if (typeof file === "string") {
                    msg += file;
                    if (typeof line === "string" || typeof line === "number") {
                        msg += "(" + line;
                        if (typeof column === "string" || typeof column === "number") {
                            msg += "," + column;
                        }
                        msg += ")";
                    }
                    msg += ": ";
                }
                else {
                    msg += "QUnit: "
                }

                msg += "error QUnit: ";
                msg += comment;

                window.external.LogComment("\n" + msg);
            }
        }

        QUnit.testDone = function (result) {
            if (result.failed !== 0) {
                LiveUnit.LoggingCore.logComment("Test case '" + result.name + "' failed. Below are error details:");
                for (var i = 0; i < failedMessages.length; i++) {
                    LiveUnit.LoggingCore.logComment("********ERROR " + (i + 1) + " OF " + failedMessages.length + "*********");
                    LiveUnit.LoggingCore.logComment("Message: '" + failedMessages[i].message + "'.");

                    var fileInfo = extractFileInfo(failedMessages[i].source);
                    if (fileInfo === null) {
                        fileInfo = extractFileInfo(failedMessages[i].message);
                    }

                    if (fileInfo !== null) {
                        var msg = "Error in test <" + failedMessages[i].name + "> in module <" + failedMessages[i].module + ">: " + failedMessages[i].message;
                        logError(msg, fileInfo.fileName, fileInfo.line, fileInfo.column);
                    }

                    var actualExpectedMessage = "";
                    if (typeof failedMessages[i].actual !== "undefined") {
                        actualExpectedMessage += "Actual: '" + failedMessages[i].actual + "'. ";
                    }
                    if (typeof failedMessages[i].expected !== "undefined") {
                        actualExpectedMessage += "Expected: '" + failedMessages[i].expected + "'.";
                    }
                    if (actualExpectedMessage) {
                        LiveUnit.LoggingCore.logComment(actualExpectedMessage);
                    }

                    if (typeof failedMessages[i].source !== "undefined") {
                        LiveUnit.LoggingCore.logComment("Source: '" + failedMessages[i].source + "'.");
                    }
					
					if (i === (failedMessages.length - 1)) {
						LiveUnit.LoggingCore.logComment("*********END OF ERRORS*******");
					}
                }
            }
        };

        QUnit.done = function (result) {
            finalResult = result;
            liveUnitWrappedCallback();
        };

    };
}());