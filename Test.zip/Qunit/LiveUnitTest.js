﻿function AsyncTests() {

    this.testAsync = function (signalTestCaseCompleted) {
        runQunitTestCases(signalTestCaseCompleted);        
    }
    this.testAsync["LiveUnit.IsAsync"] = true;    

}
LiveUnit.registerTestClass("AsyncTests");
