/*
 * Minifier options: �norename:w,d -rename:tag=t,scr=r,qname=u,initUET=f,initData=o,rs=s
 * Minifier options are passed via $(AjaxOptions) in UET.csproj to the minification targets.
 * NOTE: Always check the minified version does not have repeated variable names in different scopes.
 *       This is mainly need to keep developer documentation less confusing.
 */
(function (w, d, tag, scr, qname) {
	// Create 'uetq' global array
    w[qname] = w[qname] || [];

    // Success callback for when the file has been downloaded
    var initUET = function () {
        /*
           Any data that is required for initialization of the library.
           This will typically include any fields that need to be sent with every G call
		*/
        var initData = { ti: "%tagId%" };

        /*
           Transforms the global uet queue, uetq, into 'uetq' object
           Queued events are available through UTE object 'evq' property
        */
        initData.q = w[qname];
        w[qname] = new UET(initData);

        // Tigger pageLoad event
        w[qname].push("pageLoad");
    };

    /*
       Add the script tag to the page and set up the listeners so that the
       initialization function is called when the script has finished downloading.
	 */
    var n = d.createElement(tag);
    n.src = scr;
    n.async = 1;
    n.onload = n.onreadystatechange = function () {
        var rs = this.readyState;
        if (!rs || rs === "loaded" || rs === "complete") {
            initUET();
            n.onload = n.onreadystatechange = null;
        }
    };

    var s = d.getElementsByTagName(tag)[0];
    s.parentNode.insertBefore(n, s);
})(window, document, "script", "//bat.bing.com/bat.js", "uetq");