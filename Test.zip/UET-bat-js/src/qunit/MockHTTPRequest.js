// JavaScript source code

function XMLHttpRequest() {
    this.withCredentials = true;
    //XMLHttpRequest.calls = {};
    this.index = new Date().getTime() + Math.random();
    XMLHttpRequest.calls[this.index] = {};
    
};

XMLHttpRequest.calls = {};

XMLHttpRequest.prototype.setWithCredentials = function(value) {
    this.withCredentials = value;
};

XMLHttpRequest.prototype.open = function (method, url) {
    console.log("open called " + method + " " + url + " " + this.index);
    XMLHttpRequest.calls[this.index]["method"] = method;
    XMLHttpRequest.calls[this.index]["url"] = url;
};

XMLHttpRequest.prototype.send = function (data) {
    console.log("send called " + data);
    XMLHttpRequest.calls[this.index]["data"] = data;
};

XMLHttpRequest.prototype.setRequestHeader = function (headerKey, headerValue) {
    XMLHttpRequest.calls[this.index]["headerKey"] = headerKey;
    XMLHttpRequest.calls[this.index]["headerValue"] = headerValue;
};




// JavaScript source code

function XDomainRequest() {
    this.withCredentials = true;
    //XDomainRequest.calls = {};
    this.index = new Date().getTime();
    XMLHttpReXDomainRequestquest.calls[this.index] = {};

};


XDomainRequest.prototype.open = function (method, url) {
    XDomainRequest.calls[this.index]["method"] = method;
    XDomainRequest.calls[this.index]["url"] = url;
};

XDomainRequest.prototype.send = function (data) {
    XDomainRequest.calls[this.index]["data"] = data;
};

XDomainRequest.prototype.setRequestHeader = function (headerKey, headerValue) {
    XDomainRequest.calls[this.index]["headerKey"] = headerKey;
    XDomainRequest.calls[this.index]["headerValue"] = headerValue;
};

