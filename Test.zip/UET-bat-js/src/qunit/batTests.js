/*global module, microsoft*/
(function () {
    'use strict';

    function isIE() {
        var myNav = navigator.userAgent.toLowerCase();
        return (myNav.indexOf('msie') !== -1) ? parseInt(myNav.split('msie')[1]) : false;
    }

    function isFireFox() {
        var myNav = navigator.userAgent.toLowerCase();
        return (myNav.indexOf('firefox') !== -1) ? true : false;
    }

    function verifyCookie(uet, cookieName, cookieExpirationTime, cookieValuePrefix, cookieValueMaxLength, deleteFirst, cookieValue) {
        uet.setCookie(cookieName, cookieValue, cookieExpirationTime, deleteFirst, cookieValuePrefix, cookieValueMaxLength);

        return cookieValue === uet.getCookie(cookieName, cookieValuePrefix, cookieValueMaxLength);
    }

    function removeCookie(uet, cookieName) {
        var pastDate = new Date();

        pastDate.setTime(0);
        uet._setCookie(cookieName, '', pastDate.toUTCString(), '');
    }

    module('BAT', {
        setup: function () {
            /*
               Any data that is required for initialization of the library.
               This will typically include any fields that need to be sent with every G call
           */
            var initData = {
                advertiserId: '12345',
                tagId: 'abcde',
                debug: { batDomain: '127.0.0.1' }   // don't fire any actual calls to prod bat.bing.com
            };

            /*
               Initialize the UET object
            */
            window.uet = new UET(initData);
            XMLHttpRequest.calls = {};
        },
        teardown: function () {
            window.uet = null;
            XMLHttpRequest.calls = {};
        }
    });

    test('Init test', function () {
        ok(typeof window.uet === 'object');
        ok(typeof window.uet.evt === 'function');
        expect(2);
    });

    test('Beacon URLs', function () {
        // Version 1 snippet data
        var initData = {
            advertiserId: '12345',
            tagId: 'abcde',
            Ver: '1'
        };
        var uetx = new UET(initData);
        assert.ok(uetx.domain === 'bat.bing.com', 'Domain is properly set.');
        assert.ok(uetx.postURL === window.location.protocol + '//bat.bing.com/action/12345', 'Post url is properly set.');

        // Version 2 snippet data since 'q' is passed
        initData = {
            advertiserId: '6789',
            tagId: 'fghi',
            q: []
        };
        var uety = new UET(initData);
        assert.ok(uety.domain === 'bat.bing.com', 'Domain is properly set.');
        assert.ok(uety.postURL === window.location.protocol + '//bat.bing.com/action/0', 'Post url is properly set.');

        expect(4);
    });

    test('ev & gv validations', function () {
        // Format: ev, gv, use quotes around keys?, expected ev, expected gv, exception message, test message
        var cases = [['22', '22.1', true, 22, 22.1, '', 'Basic check.'],
                     [0, 0, true, 0, 0, '', 'ev and gv zeros.'],
                     ['0', '0', true, 0, 0, '', 'ev and gv quoted zeros.'],
                     //['-22', '-22.1', true, -22, -22.1, '', 'negative values.'],
                     ['+22.0', '+00220.100', true, 22, 220.1, '', 'values with plus sign prefix.'],
                     ['2', '2.012', true, 2, 2.012, '', 'gv with 4 decimal places.'],
                     //['2.0', '-2.0012', true, 2, -2.0012, '', 'decimal point in ev with zero in first decimal place.'],
                     //['0002010.0000', '-2.0012', true, 2010, -2.0012, '', 'decimal point in ev with more zeros before and after decimal point.'],
                     //['2.', '-2.0012', true, 2, -2.0012, '', 'decimal point in ev without any digit after decimal point.'],
                     ['999999999999', '999999999999', true, 999999999999, 999999999999, '', 'max ev and gv value check.'],
                     //['-999999999999', '-999999999999', true, -999999999999, -999999999999, '', 'large negative ev and gv value check.'],
                     //['2', '0.000000000000000000001', true, 2, undefined, '', 'very small gv value check.'],
                     [',,,2,2,2,', '99,9,9,9,.01,2', true, 222, 99999.012, '', 'values with random commas.'],
                     ['9,999,', '99,999.999', true, 9999, 99999.999, '', 'values with well defined commas.'],
                     ['22', '22.1', false, 22, 22.1, '', 'without quotes around keys.'],
                     [22, 22.1, true, 22, 22.1, '', 'without quotes around values.'],
                     [22, 22.1, false, 22, 22.1, '', 'without quotes around keys and values.'],
                     ['10000000000000', '9999', true, -1, -1, 'ev cannot be greater than 999999999999', 'ev greater than max value.'],
                     ['9999', '999999999999.01', true, -1, -1, 'gv cannot be greater than 999999999999', 'gv greater than max value.'],
                     //['2.1', '-2.012', true, -1, -1, 'ev should be an integer', 'ev fractional value.'],
                     ['.1', '2.012', true, .1, 2.012, 'ev should be an integer', 'ev with decimal point at the beginning.'],
                     ['010', '.012', true, 10, 0.012, '', 'gv with decimal point at the beginning.'],
                     //['010', '-.0012', true, 10, -0.0012, '', 'gv with decimal point at the beginning and negative sign.'],
                     ['010', '+.012', true, 10, 0.012, '', 'gv with decimal point at the beginning and positive sign.'],
                     //['2$1', '-2.012', true, -1, -1, 'ev should be an integer', 'ev with $ inbetween.'],
                     //['', '2', true, -1, -1, 'ev should be an integer', 'ev nan (ev empty value).'],
                     //['abc', '2', true, -1, -1, 'ev should be an integer', 'ev nan (ev=\'abc\').'],
                     //['$2', '2', true, -1, -1, 'ev should be an integer', 'ev nan (ev=\'$2\').'],
                     //['2$', '2', true, -1, -1, 'ev should be an integer', 'ev nan (ev=\'2$\').'],
                     [22, '', true, -1, -1, 'gv should be a number', 'gv nan (gv empty value).'],
                     ['22', 'abc', true, -1, -1, 'gv should be a number', 'gv nan (gv=\'abc\').'],
                     ['2', '$2', true, -1, -1, 'gv should be a number', 'gv nan (gv=\'$2\').'],
                     ['2', '2$', true, -1, -1, 'gv should be a number', 'gv nan (gv=\'2$\').'],
                     [2, '$2', false, -1, -1, 'gv should be a number', 'unquoted key and gv nan (gv=\'$2\').'],
                     //['2dollars', '2', true, -1, -1, 'ev should be an integer', 'ev with characters at the end.'],
                     ['2', '2rupees', true, -1, -1, 'gv should be a number', 'gv with characters at the end.'],
                     //['abc2', '2', true, -1, -1, 'ev should be an integer', 'ev with characters at the front.'],
                     ['2', 'd2', true, -1, -1, 'gv should be a number', 'gv with characters at the front.']];

        function validate(data) {
            for (var i = 0; i < data.length; i++) {
                var d = data[i][2] ? { 'ev': data[i][0], 'gv': data[i][1] } : { ev: data[i][0], gv: data[i][1] };
                try {
                    uet.validateDataObject(uet.customEvt, d);
                    assert.ok(d.ev === data[i][3] && d.gv === data[i][4], data[i][6]);
                } catch (err) {
                    assert.ok(err.toString() === data[i][5], data[i][6]);
                }
            }
        }
        validate(cases);
        expect(cases.length);
    });

    test('dispatchq event queue tests', function () {
        var eq = [];
        function reset() {
            uet.evq = [];
            eq = [];
            uet.push = function () { eq.push(Array.prototype.slice.call(arguments)); }
            //uet.push = (...args) => eq.push(args);
        }
        function fire(evs) {
            // flatten events to simulate push one by one to array before page load
            for (var ev in evs)
                for (var i in evs[ev])
                    uet.evq.push(evs[ev][i]);
            uet.dispatchq();
        }

        var cases = [
        //  [ description                                       events                                                          expected (if it differs)                                            ],
            [ 'single old style event',                         [ [{ ea: 'action' }] ]                                                                                                              ],
            [ 'single new style event no args',                 [ ['event', 'action'] ],                                        [ ['event', 'action', {}] ]                                         ],
            [ 'two new style events no args',                   [ ['event', 'one'], ['event', 'two'] ],                         [ ['event', 'one', {}], ['event', 'two', {}] ]                      ],
            [ 'single new style event empty args',              [ ['event', 'action', {}] ]                                                                                                         ],
            [ 'single new style event with args',               [ ['event', 'action', {event_label: 'label'}] ]                                                                                     ],
            [ 'new style with params followed by old style',    [ ['event', 'new', {event_label: 'label'}], [{ea: 'old'}]]                                                                          ],
            [ 'new style without params followed by old style', [ ['event', 'new'], [{ea: 'old'}] ],                            [ ['event', 'new', {}], [{ea: 'old'}] ]                             ],
            [ 'new style without params followed by new style', [ ['event', 'new'], ['event', 'old', {event_label: 'label'}] ], [ ['event', 'new', {}], ['event', 'old', {event_label: 'label'}] ]  ],
            [ 'legacy params disambiguation old wins',          [ ['event', 'new', {el: 'label'}] ],                            [ ['event', 'new', {}], [{el: 'label'}] ]                           ],
            [ 'legacy params disambiguation new wins',          [ ['event', 'new', {event_label: 'label'}] ],                   [ ['event', 'new', {event_label: 'label'}] ]                        ],
            [ 'ambiguous params merged to one new event',       [ ['event', 'new'], [{ecomm_prodid: 123}] ],                    [ ['event', 'new', {ecomm_prodid: 123}] ]                           ],
            [ 'ambiguous and legacy params kept as two events', [ ['event', 'new'], [{ecomm_prodid: 123, ea: 'old'}] ],         [ ['event', 'new', {}], [{ecomm_prodid: 123, ea: 'old'}] ]          ],
            [ 'set event',                                      [ ['set', {currency: 'USD'}] ]                                                                                                      ],
            [ 'set event followed by old style event',          [ ['set', {currency: 'USD'}], [{ ea: 'action' }] ]                                                                                  ],
            [ 'set event followed by new style event',          [ ['set', {currency: 'USD'}], ['event', 'action', {event_label: 'label'}] ]                                                         ],
            [ 'set event preceeded by new style event no args', [ ['event', 'action'], ['set', {currency: 'USD'}] ],            [ ['event', 'action', {}], ['set', {currency: 'USD'}] ]             ],
        ];

        for (var c in cases)
        {
            reset();
            fire(cases[c][1]);
            assert.deepEqual(eq, cases[c][2] !== undefined ? cases[c][2] : cases[c][1], cases[c][0]);
        }

        expect(cases.length);
    });

    test('push invoke tests', function () {
        function reset() {
            uet.pageLoadDispatch = false;
            uet.invisibleDiv = null;
        }
        function resetPush(d1, d2, d3) {
            reset();
            if (d2 === undefined && d3 === undefined) {
                uet.push(d1);
            } else if (d3 === undefined) {
                uet.push(d1, d2);
            } else {
                uet.push(d1, d2, d3);
            }
        }

        expect(19);

        resetPush();
        assert.ok(uet.invisibleDiv === null, 'No event dispatched.');
        resetPush('');
        assert.ok(uet.invisibleDiv === null, 'event not dispatched for \'\'.');
        resetPush(uet.pageLoadEvt);
        assert.ok(uet.pageLoadDispatch === true && uet.invisibleDiv !== null, 'pageLoad event dispatched.');
        resetPush([uet.pageLoadEvt]);
        assert.ok(uet.pageLoadDispatch === false && uet.invisibleDiv === null, 'pageLoad event not dispatched for [\'pageLoad\'] form.');
        resetPush(uet.pageLoadEvt, {});
        assert.ok(uet.pageLoadDispatch === false, 'pageLoad event not dispatched for empty data.');
        resetPush(uet.pageLoadEvt, {'gv': 1000});
        assert.ok(uet.pageLoadDispatch === false, 'pageLoad event not dispatched for extra data.');
        resetPush(uet.customEvt);
        assert.ok(uet.invisibleDiv === null, 'custom event not dispatched.');
        resetPush({});
        assert.ok(uet.invisibleDiv === null, 'custom event not dispatched for empty data.');
        resetPush('blah');
        assert.ok(uet.invisibleDiv === null, 'custom event not dispatched for \'blah\'.');
        resetPush([{ 'gv': 1000 }]);
        assert.ok(uet.invisibleDiv !== null, 'custom event dispatched for array data.');
        resetPush({ 'gv': 2000 });
        assert.ok(uet.invisibleDiv !== null, 'custom event dispatched for valid data.');
        resetPush([uet.customEvt, { 'gv': 100 }]);
        assert.ok(uet.invisibleDiv === null, 'custom event not dispatched for array form.');
        try {
            resetPush({ 'gvxyz': 2000 });
        } catch (err) {
            assert.ok(err.toString() === uet.invalidKeyException + 'gvxyz', 'Event not dispatched for data with key gvxyz.');
        }
        resetPush('event', '');
        assert.ok(uet.invisibleDiv === null, 'custom event not dispatched for new format event empty name.');
        resetPush('event', '', {});
        assert.ok(uet.invisibleDiv === null, 'custom event not dispatched for new format event empty name empty params.');
        resetPush('event', 'action');
        assert.ok(uet.invisibleDiv !== null, 'custom event dispatched for new format event name only.');
        resetPush('event', 'action', {});
        assert.ok(uet.invisibleDiv !== null, 'custom event dispatched for new format event name with empty params.');
        resetPush('event', '', { event_category: 'category' });
        assert.ok(uet.invisibleDiv !== null, 'custom event dispatched for new format event empty name with params.');
        resetPush('event', 'action', { event_category: 'category' });
        assert.ok(uet.invisibleDiv !== null, 'custom event dispatched for new format event name with params.');
    });

    test('SPA tests', function() {
        var valid = [];
        function reset() {
            valid = [];
            uet.previousPage = null;
            uet.pageLoadDispatch = false;
            uet.invisibleDiv = null;
            uet.pageLevelParams = {};
            uet.fireBeacon = function (d) { valid.push(d); }
        }
        expect(63);

        var urlData = {};
        urlData = uet.addUrlData(urlData);

        // manual page view (non-SPA)
        reset();
        uet.evt('pageLoad', 'page_view', {}, false);
        assert.strictEqual(valid.length, 1, 'one event fired.');
        assert.strictEqual(valid[0].evt, 'pageLoad', 'pageLoad event type set.');
        assert.strictEqual(valid[0].ea, undefined);
        assert.strictEqual(valid[0].abf, true, 'beacon call attempted.');
        assert.strictEqual(valid[0].spa, undefined, 'SPA page view flag not set.');
        assert.strictEqual(uet.pageLoadDispatch, true, 'page load flag set.');

        // SPA page view without an auto page load
        reset();
        uet.evt('pageLoad', 'page_view', { page_path: '/spa_page', page_title: 'test SPA page' }, false);
        assert.strictEqual(valid.length, 1, 'one event fired.');
        assert.strictEqual(valid[0].evt, 'pageLoad', 'pageLoad event type set.');
        assert.strictEqual(valid[0].abf, true, 'beacon call attempted.');
        assert.strictEqual(valid[0].spa, 'Y', 'SPA page view flag set.');
        assert.strictEqual(uet.pageLoadDispatch, true, 'page load flag set for SPA event.');
        assert.strictEqual(valid[0].tl, encodeURIComponent('test SPA page'), 'tl set based on page_title.');
        assert.strictEqual(valid[0].page_title, undefined, 'page_title not set since it is redundant with tl.');
        assert.strictEqual(valid[0].p, encodeURIComponent(window.location.origin + '/spa_page'), 'page set based on page_path and previousPage.');
        assert.strictEqual(valid[0].r, urlData.r, 'referrer set to document referrer.');
        assert.strictEqual(uet.previousPage, valid[0].p, 'previousPage set to page.');

        // SPA page view after an auto page load
        reset();
        var oldMid = uet.beaconParams.mid;
        uet.evt('pageLoad', 'page_view', {}, true);
        assert.strictEqual(uet.pageLoadDispatch, true, 'page load flag set.');
        valid = [];
        uet.evt('pageLoad', 'page_view', { page_path: '/spa_page' }, false);
        assert.notEqual(oldMid, uet.beaconParams.mid, 'mid changed.');
        assert.strictEqual(valid.length, 1, 'one event fired.');
        assert.strictEqual(valid[0].spa, 'Y', 'SPA page view flag set.');
        assert.strictEqual(valid[0].p, encodeURIComponent(window.location.origin + '/spa_page'), 'page set based on page_path and previousPage.');
        assert.strictEqual(valid[0].r, urlData.p, 'referrer set to document page.');

        // SPA page view before a manual page load
        reset();
        oldMid = uet.beaconParams.mid;
        uet.evt('pageLoad', 'page_view', { page_path: '/spa_page' }, false);
        assert.strictEqual(oldMid, uet.beaconParams.mid, 'mid not changed.');
        assert.strictEqual(uet.pageLoadDispatch, true, 'page load flagset.');
        assert.strictEqual(valid.length, 1, 'one event fired.');
        assert.strictEqual(valid[0].spa, 'Y', 'SPA page view flag set.');
        assert.strictEqual(valid[0].p, encodeURIComponent(window.location.origin + '/spa_page'), 'page set based on page_path and previousPage.');
        assert.strictEqual(valid[0].r, urlData.r, 'referrer set to document referrer.');
        valid = [];
        uet.evt('pageLoad', 'page_view', {}, false);
        assert.strictEqual(valid.length, 0, 'nothing fired.');
        assert.strictEqual(oldMid, uet.beaconParams.mid, 'mid not changed.');

        // manual page view after auto pageLoad (should not fire)
        reset();
        uet.evt('pageLoad', 'page_view', {}, true);
        assert.strictEqual(uet.pageLoadDispatch, true, 'page load flag set.');
        valid = [];
        uet.evt('pageLoad', 'page_view', {}, false);
        assert.strictEqual(valid.length, 0, 'manual page view not fired.');

        // three SPA page views after auto pageLoad
        reset();
        oldMid = uet.beaconParams.mid;
        uet.evt('pageLoad', 'page_view', {}, true);
        assert.strictEqual(valid.length, 1, 'one event fired.');
        assert.strictEqual(valid[0].evt, 'pageLoad', 'pageLoad event type set.');
        assert.strictEqual(valid[0].spa, undefined, 'SPA page view flag not set.');
        assert.strictEqual(uet.pageLoadDispatch, true, 'page load flag set.');
        valid = [];
        uet.evt('pageLoad', 'page_view', { page_path: '/spa_page' }, false);
        assert.notEqual(oldMid, uet.beaconParams.mid, 'mid changed.');
        oldMid = uet.beaconParams.mid;
        uet.evt('pageLoad', 'page_view', { page_path: '/second_spa' }, false);
        assert.notEqual(oldMid, uet.beaconParams.mid, 'mid changed.');
        oldMid = uet.beaconParams.mid;
        uet.evt('pageLoad', 'page_view', { page_path: 'spa_three' }, false);
        assert.notEqual(oldMid, uet.beaconParams.mid, 'mid changed.');
        assert.strictEqual(valid.length, 3, 'three events fired.');
        assert.strictEqual(valid[0].p, encodeURIComponent(window.location.origin + '/spa_page'), 'page set based on page_path.');
        assert.strictEqual(valid[0].page_path, encodeURIComponent('/spa_page'));
        assert.strictEqual(valid[0].r, urlData.p, 'referrer set to document page.');
        assert.strictEqual(valid[1].p, encodeURIComponent(window.location.origin + '/second_spa'), 'page set based on page_path.');
        assert.strictEqual(valid[1].page_path, encodeURIComponent('/second_spa'));
        assert.strictEqual(valid[1].r, valid[0].p, 'referrer set based on previousPage.');
        assert.strictEqual(valid[1].p, valid[1].p, 'page not changed because page_path missing starting slash.');
        assert.strictEqual(valid[2].page_path, encodeURIComponent('spa_three'));
        assert.strictEqual(valid[2].r, valid[1].p, 'referrer set based on previousPage.');

        // empty p param (simulates iframe where referrer is not passed and p is empty; can happen on downgrade http->https)
        reset();
        var oldAddPageData = uet.addPageData;
        oldMid = uet.beaconParams.mid;
        uet.addPageData = function (data) { return data; }  // NOTE: hacky hook to force addPageData to not set p & r
        uet.evt('pageLoad', 'page_view', {}, true);
        assert.strictEqual(oldMid, uet.beaconParams.mid, 'mid not changed.');
        assert.strictEqual(uet.pageLoadDispatch, true, 'page load flag set.');
        uet.evt('pageLoad', 'page_view', { page_path: '/spa_page', page_title: 'test SPA page' }, false);
        assert.notEqual(oldMid, uet.beaconParams.mid, 'mid changed.');
        assert.strictEqual(valid.length, 2, 'two events fired.');
        assert.strictEqual(valid[0].evt, 'pageLoad', 'pageLoad event type set.');
        assert.strictEqual(valid[0].spa, undefined, 'SPA page view flag not set.');
        assert.strictEqual(valid[0].p, undefined, 'p not set.');
        assert.strictEqual(valid[0].r, undefined, 'r not set.');
        assert.strictEqual(valid[1].evt, 'pageLoad', 'pageLoad event type set.');
        assert.strictEqual(valid[1].spa, 'Y', 'SPA page view flag set.');
        assert.strictEqual(valid[1].p, undefined, 'p not set.');
        assert.strictEqual(valid[1].r, undefined, 'r not set.');
        assert.strictEqual(valid[1].page_path, encodeURIComponent('/spa_page'), 'page_path set.');
        assert.strictEqual(valid[1].tl, encodeURIComponent('test SPA page'), 'tl set based on page_title.');
        uet.addPageData = oldAddPageData;
    });

    test('page level param tests', function() {
        var valid = {};
        function reset() {
            uet.pageLoadDispatch = false;
            uet.invisibleDiv = null;
            uet.pageLevelParams = {};
            uet.fireBeacon = function (d) { valid = d; }
        }
        expect(16);

        // no items param if not set in event or page level params
        reset();
        var data = {};
        uet.evt('custom', 'begin_checkout', data, false);
        assert.strictEqual(valid.evt, 'custom', 'custom event type set.');
        assert.strictEqual(valid.abf, true, 'beacon call attempted.');
        assert.strictEqual(valid.ea, 'begin_checkout', 'ea set to begin_checkout.');
        assert.strictEqual(valid.items, undefined, 'items param not included.');

        // items param included on whitelisted event if set in page level params
        reset();
        data = {};
        uet.push('set', { items: [ { id: 'ABC123' } ] });
        uet.evt('custom', 'begin_checkout', data, false);
        assert.strictEqual(valid.evt, 'custom', 'custom event type set.');
        assert.strictEqual(valid.abf, true, 'beacon call attempted.');
        assert.strictEqual(valid.ea, 'begin_checkout', 'ea set to begin_checkout.');
        assert.strictEqual(valid.items, encodeURIComponent('id=ABC123'), 'items param included.');

        // items param not included on non-whitelisted event if set in page level params
        reset();
        data = {};
        uet.push('set', { items: [ { id: 'ABC123' } ] });
        uet.evt('custom', 'event_name', data, false);
        assert.strictEqual(valid.evt, 'custom', 'custom event type set.');
        assert.strictEqual(valid.abf, true, 'beacon call attempted.');
        assert.strictEqual(valid.ea, 'event_name', 'ea set to event_name.');
        assert.strictEqual(valid.items, undefined, 'items param not included.');

        // items param overrided by event params
        reset();
        data = { items: [ { id: 'DEF456' } ] };
        uet.push('set', { items: [ { id: 'ABC123' } ] });
        uet.evt('custom', 'begin_checkout', data, false);
        assert.strictEqual(valid.evt, 'custom', 'custom event type set.');
        assert.strictEqual(valid.abf, true, 'beacon call attempted.');
        assert.strictEqual(valid.ea, 'begin_checkout', 'ea set to begin_checkout.');
        assert.strictEqual(valid.items, encodeURIComponent('id=DEF456'), 'items param included.');
    });

    test('trim tests', function () {
        var url;
        var data = {};
        function reset() {
            uet.initData = {};
            uet.fireBeaconImg = function (u) { url = u; }
        }
        function test(data)
        {
            reset();
            uet.fireBeacon(data);
            var d = {};
            url.replace(/([^=&]+)=([^&]*)/g, function(m, k, v) { d[decodeURIComponent(k)] = decodeURIComponent(v); });
            return d;
        }
        function longStr()
        {
            return Array(uet.URLLENGTHLIMIT).join('X');
        }

        expect(15);

        data = { ea: 'action' };
        data = test(data);
        assert.ok(data.hasOwnProperty('ea'), 'no trim');

        data = { el: 'label', el2: longStr() };
        data = test(data);
        assert.ok(data.hasOwnProperty('el'), 'el not dropped');
        assert.ok(data.hasOwnProperty('el2'), 'el2 not dropped');
        assert.strictEqual(data.el2.length, 0, 'el2 set to empty');

        data = { ea: 'action', kw: longStr() };
        data = test(data);
        assert.ok(data.hasOwnProperty('ea'), 'ea not dropped');
        assert.ok(!data.hasOwnProperty('kw'), 'kw dropped');

        data = { ea: 'action', ea2: longStr(), kw: 'keywords' };
        data = test(data);
        assert.ok(data.hasOwnProperty('ea'), 'ea not dropped');
        assert.ok(data.hasOwnProperty('ea2'), 'ea2 not dropped');
        assert.strictEqual(data.ea2.length, 0, 'ea2 set to empty');
        assert.ok(data.hasOwnProperty('kw'), 'kw not dropped');

        data = { el: 'label', el2: longStr(), kw: longStr(), p: 'page' };
        data = test(data);
        assert.ok(data.hasOwnProperty('el'), 'el not dropped');
        assert.ok(data.hasOwnProperty('el2'), 'el2 not dropped');
        assert.strictEqual(data.el2.length, 0, 'el2 set to empty');
        assert.ok(!data.hasOwnProperty('kw'), 'kw dropped');
        assert.ok(data.hasOwnProperty('p'), 'p not dropped');
    });

    test('evt invoke tests', function () {
        expect(29);

        uet.evt('pageLoad');
        assert.ok(true, 'No data is ok.');

        var tdata = null;
        uet.evt('pageLoad', 'page_view', tdata);
        assert.ok(true, 'Null data is ok.');
        assert.ok(tdata === null, 'Data object passed as null.');

        var edata = '';
        uet.evt('pageLoad', 'page_view', edata);
        assert.ok(true, ' data is ok.');
        assert.ok(edata.evt === undefined, ' data - event data is not returned from evt call.');
        assert.ok(uet.pageLoadDispatch === true, ' data - pageLoad fired.');

        var tdataEmpty = {};
        uet.pageLoadDispatch = false;
        uet.evt('pageLoad', 'page_view', tdataEmpty);
        assert.ok(true, '{} data is ok.');
        assert.ok(tdataEmpty.evt === 'pageLoad', 'Event type was set in data object passed as {}.');
        assert.ok(tdataEmpty.abf === true, '{} data - beacon call attempted.');
        assert.ok(uet.pageLoadDispatch === true, '{} data - pageLoad fired.');

        // re-attempt 'pageLoad' event
        var rePageLoad = {};
        uet.evt('pageLoad', 'page_view', rePageLoad);
        assert.ok(true, 'refire pageLoad - call ok.');
        assert.ok(rePageLoad.evt === undefined, 'refire pageLoad - skipped validation and beacon firing.');
        assert.ok(rePageLoad.abf === undefined, 'refire pageLoad - beacon call not attempted.');
        assert.ok(uet.pageLoadDispatch === true, 'refire pageLoad - was previously fired.');

        var ec = 'abcd';
        var ea = 'Play';
        var ev = 123;
        var el = 'xyz';
        var tdataValidCustomEv = { 'ec': ec, 'ea': ea, 'ev': ev, 'el': el };
        uet.evt('custom', null, tdataValidCustomEv);
        assert.ok(true, 'valid data with custom event type - call ok.');
        assert.ok(tdataValidCustomEv.evt === 'custom', 'Custom event type was set in data object passed.');
        assert.ok(tdataValidCustomEv.abf === true, 'valid data with custom event type - beacon call attempted.');
        assert.strictEqual(undefined, tdataValidCustomEv.en, 'new style event flag not set.');

        // new style events throw away the input object for safety, need to wrap to get the validated object
        var valid = {};
        uet.fireBeacon = function (d) { valid = d; }

        var gc = 'USD';
        var gv = 456;
        var tdataValidNewCustomEv = { 'event_category': ec, 'event_value': ev, 'event_label': el, 'currency': gc, 'revenue_value': gv }
        uet.evt('custom', ea, tdataValidNewCustomEv, false);
        assert.ok(true, 'valid data with new custom event type - call ok.');
        assert.strictEqual(valid.evt, 'custom', 'Custom event type was set in data object passed.');
        assert.strictEqual(valid.abf, true, 'valid data with custom event type - beacon call attempted.');
        assert.strictEqual(valid.en, 'Y', 'new style event flag set.');
        assert.strictEqual(valid.ea, ea, 'event action rewritten to ea.');
        assert.ok(valid.event_value === undefined, 'event_value value removed.');
        assert.strictEqual(valid.ev, ev, 'event value rewritten to ev.');
        assert.ok(valid.currency === undefined, 'currency value removed.');
        assert.strictEqual(valid.gc, gc, 'currency value rewritten to gc.');
        assert.ok(valid.revenue_value === undefined, 'revenue value removed.');
        assert.strictEqual(valid.gv, gv, 'revenue value rewritten to gv.');
    });

    test('validation - Allowed evt keys', function () {
        expect(40);

        try {
            uet.validateDataObject();
        } catch (err) {
            assert.ok(err.toString() === uet.invalidEventException + 'undefined event.', 'Undefined event not accepted.');
        }

        try {
            uet.validateDataObject('blah');
        } catch (err) {
            assert.ok(err.toString() === uet.invalidEventException + 'blah', 'Invalid event type \'blah\' not accepted.');
        }

        try {
            uet.validateDataObject('');
        } catch (err) {
            assert.ok(err.toString() === uet.invalidEventException + 'undefined event.', 'Invalid event type \'\' not accepted.');
        }

        try {
            uet.validateDataObject(uet.pageLoadEvt);
        } catch (err) {
            assert.ok(err.toString() === 'undefined data object passed to validate', 'Undefined data not accepted.');
        }

        uet.validateDataObject(uet.pageLoadEvt, {});
        assert.ok(true, 'pageLoad event accepted with empty data.');

        uet.validateDataObject(uet.customEvt, {});
        assert.ok(true, 'custom event accepted with empty data.');

        var ec = 'abcd';
        var ea = 'Play';
        var ev = 123;
        var el = 'xyz';
        var tdata = { 'ec': ec, 'ea': ea, 'ev': ev, 'el': el };
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'Basic validation of keys passed.');

        tdata.invalid = 'invalid';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidKeyException + 'invalid', 'Invalid key not accepted.');
        }
        delete tdata.invalid;

        // tdata.ev = 'one';
        // try {
        //     uet.validateDataObject(uet.pageLoadEvt, tdata);
        // } catch (err) {
        //     assert.ok(err.toString() === 'ev should be an integer', 'Invalid ev key not accepted.');
        // }

        tdata.ev = 99;
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'ev paramater numeric validation passed.');

        try {
            uet.validateDataObject(uet.customEvt);
        } catch (err) {
            assert.ok(err.toString() === 'undefined data object passed to validate', 'Undefined data not accepted.');
        }

        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'Basic validation of key for custom event passed.');

        tdata.gv = 'one';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === 'gv should be a number', 'Invalid gv key not accepted.');
        }

        // Goal currency tests
        tdata.gv = 123;
        tdata.gc = 'USD';

        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'Basic validation of key for custom event passed.');

        tdata.gc = 'USDA';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === 'gc value must be ISO standard currency code', 'Invalid length gc key not accepted. Length must be equal to 3.');
        }

        tdata.gc = 'A23';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === 'gc value must be ISO standard currency code', 'Invalid format gc key not accepted. String must contain only alphabets (a-z), not numbers or other characters.');
        }
        tdata.gc = 'USD';

        // Encoding tests
        tdata.ea = '#and&';
        tdata.el = '#and&';
        tdata.ec = '#and&';
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(tdata.ea === '%23and%26', 'Encoding test ea');
        assert.ok(!('ea2' in tdata), 'No ea2');
        assert.ok(tdata.el === '%23and%26', 'Encoding test el');
        assert.ok(!('el2' in tdata), 'No el2');
        assert.ok(tdata.ec === '%23and%26', 'Encoding test ec');
        assert.ok(!('ec2' in tdata), 'No ec2');
        tdata.ea = null;
        tdata.el = '#and&';
        tdata.ec = '#and&';
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(tdata.ea === null, 'ea null value ignored');
        tdata.ea = '#and&';
        tdata.el = '#and&';
        tdata.ec = undefined;
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(tdata.ec === undefined, 'ec undefined value ignored');

        // ea2/el2/ec2
        tdata.ea = '#and&and|';
        tdata.el = '&and|and#';
        tdata.ec = '|and#and&';
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(tdata.ea === '%23and%26and|', 'Encoding test ea');
        assert.ok(tdata.ea2 === '%23and%26and%7C', 'Encoding test ea2');
        assert.ok(tdata.el === '%26and|and%23', 'Encoding test el');
        assert.ok(tdata.el2 === '%26and%7Cand%23', 'Encoding test el2');
        assert.ok(tdata.ec === '|and%23and%26', 'Encoding test ec');
        assert.ok(tdata.ec2 === '%7Cand%23and%26', 'Encoding test ec2');
        delete tdata.ea2;
        delete tdata.el2;
        delete tdata.ec2;

        // Ea2/ec2/el2 tests
        tdata.ea = '#and&';
        tdata.el = '#and&';
        tdata.ec = '#and&';

        // Hotel conversion tests
        delete tdata.gc; // currency will be sent by users as 'currency' parameter
        delete tdata.gv;
        tdata.hct_base_price = 100.50;
        tdata.hct_booking_xref = 'ABC123';
        tdata.hct_checkin_date = '2018-03-04';
        tdata.hct_checkout_date = '2018-03-08';
        tdata.hct_length_of_stay = 3;
        tdata.hct_partner_hotel_id = 'Hotel_Testing_Saint_Louis_MO_63103';
        tdata.hct_total_price = 300.50;
        tdata.hct_pagetype = 'searchresults';
        tdata.currency = 'USD';

        uet.validateDataObjectNew(uet.customEvt, tdata);
        assert.ok(true, 'Basic validation for hotel conversion passed.');

        tdata.hct_base_price = 'ABC';
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_base_price/, 'Hotel conversion paramter hct_base_price validated as expected ');
        tdata.hct_base_price = 100.50;

        tdata.hct_booking_xref = 'ABC#123';
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_booking_xref/, 'Hotel conversion paramter hct_booking_xref validated as expected ');
        tdata.hct_booking_xref = 'ABC123';

        tdata.hct_checkin_date = '03-04-2018';
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_checkin_date/, 'Hotel conversion paramter hct_checkin_date validated as expected ');
        tdata.hct_checkin_date = '2018-03-04';

        tdata.hct_checkout_date = '03-04-2018';
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_checkout_date/, 'Hotel conversion paramter hct_checkout_date validated as expected ');
        tdata.hct_checkout_date = '2018-03-08';

        tdata.hct_length_of_stay = 3.5;
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_length_of_stay/, 'Hotel conversion paramter hct_length_of_stay validated as expected ');
        tdata.hct_length_of_stay = 3;

        tdata.hct_partner_hotel_id = 'ABC#123';
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_partner_hotel_id/, 'Hotel conversion paramter hct_partner_hotel_id validated as expected ');
        tdata.hct_partner_hotel_id = '98765';

        delete tdata.hct_total_price;
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, null, 'Missing required hotel paramter validated as expected ');

        tdata.hct_total_price = -100;
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_total_price/, 'Hotel conversion paramter hct_total_price validated as expected ');
        tdata.hct_total_price = 300.50;

        tdata.gv = 100;
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, null, 'Variable revenue for hotel goals not allowed validated as expected ');
        delete tdata.gv;

        tdata.hct_pagetype = 'invalidtype';
        assert.throws(function() { uet.validateDataObjectNew(uet.customEvt, tdata) }, /hct_pagetype/, 'Hotel conversion paramter hct_pagetype validated as expected ');
        tdata.hct_pagetype = 'searchresults';
    });

    test('validation - Allowed evt keys for retail vertical', function () {
        expect(17);

        uet.validateDataObject(uet.customEvt, {});
        assert.ok(true, 'custom event accepted with empty data.');

        var prodid = '0123456789abcdef0123456789abcdef0123456789-bcdef01';
        var pagetype = 'home';
        var tdata = { 'prodid': prodid, 'pagetype': pagetype };
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'Basic validation of prodid and pagetype keys passed.');

        delete tdata.prodid;
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'Prod id is optional check');

        tdata.prodid = prodid;
        delete tdata.pagetype;
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.missingPageTypeException, 'Missing pagetype key not accepted. Actual error: ' + err.toString());
        }

        tdata.pagetype = pagetype + '_invalid_suffix';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidPageTypeException + pagetype + '_invalid_suffix', 'Invalid pagetype value not accepted. Actual error: ' + err.toString());
        }

        tdata.pagetype = '';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidPageTypeException, 'Empty pagetype value not accepted. Actual error: ' + err.toString());
        }

        tdata.pagetype = undefined;
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidPageTypeException + 'undefined', 'Null pagetype value not accepted. Actual error: ' + err.toString());
        }

        tdata.pagetype = null;
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidPageTypeException + 'null', 'Undefined pagetype value not accepted. Actual error: ' + err.toString());
        }

        tdata.pagetype = pagetype;
        tdata.prodid = 'including_invalid_characters';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidProdIdException, 'Invalid prodid value not accepted. Actual error: ' + err.toString());
        }

        tdata.pagetype = pagetype + '_invalid_suffix';
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidPageTypeException + pagetype + '_invalid_suffix', 'Invalid prodid value and invalid page type not accepted, and only pagetype exception is thrown since it is checked first.');
        }

        tdata.pagetype = pagetype;
        tdata.prodid = [prodid, 'abc123', 987];
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'Comprehensive validation of prodid and pagetype keys passed for an array of strings and numbers are provided for prodid.');

        tdata.prodid = [undefined, prodid, null, 'abc123', , , 987];
        uet.validateDataObject(uet.customEvt, tdata);
        assert.ok(true, 'Comprehensive validation of prodid and pagetype keys passed for an array of strings and numbers are provided for prodid.');

        tdata.prodid = [undefined, null, , ,];
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidProdIdException, 'Array of invalid elements for prodid value not accepted. Actual error: ' + err.toString());
        }

        tdata.prodid = [1, '2', [3, 4, 5], 6,];
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidProdIdException, 'Nested arrays for prodid value not accepted. Actual error: ' + err.toString());
        }

        tdata.prodid = [];
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidProdIdException, 'Empty array for prodid value not accepted. Actual error: ' + err.toString());
        }

        tdata.prodid = null;
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidProdIdException, 'Null prodid value not accepted. Actual error: ' + err.toString());
        }

        tdata.prodid = undefined;
        try {
            uet.validateDataObject(uet.customEvt, tdata);
        } catch (err) {
            assert.ok(err.toString() === uet.invalidProdIdException, 'Undefined prodid value not accepted. Actual error: ' + err.toString());
        }
    });

    test('createInvisibleDiv test', function () {
        var id = uet.createInvisibleDiv(document.getElementById('qunit-fixture'));
        var invDiv = document.getElementById(id);
        ok(invDiv);
        ok(invDiv.style.width === '0px');
        ok(invDiv.style.height === '0px');
        ok(invDiv.style.display === 'none');
        expect(4);
    });

    test('fireBeaconImg test', function () {
        var id = uet.createInvisibleDiv(document.getElementById('qunit-fixture'));
        var invDiv = document.getElementById(id);

        var url = 'http://www.foo.com/?x=' + Math.random('foo');
        var rvalue = uet.fireBeaconImg(url);

        var elems = invDiv.getElementsByTagName('img');

        for (var i = 0; i < elems.length; i++) {
            if (elems[i].src && elems[i].src === url + '&rn=' + rvalue) {
                ok(true);
            }
        }

        expect(1);
    });

    test('flattenObject - no parent test', function () {
        var str = uet.stringifyToRequest({ a: 'a', b: 'b' });
        ok(str === 'a=a&b=b&');
    });

    test('flattenObject - parent test', function () {
        var str = uet.stringifyToRequest({ a: 'a', b: 'b' }, 'parent');
        ok(str === 'parent.a=a&parent.b=b&');
    });

    test('flattenObject - composite object', function () {
        var str = uet.stringifyToRequest({ a: { c: 'c', d: 'd' }, b: 'b' });
        ok(str === 'a.c=c&a.d=d&b=b&');
    });

    test('flattenObject - composite object with parent', function () {
        var str = uet.stringifyToRequest({ a: { c: 'c', d: 'd' }, b: 'b' }, 'parent');
        ok(str === 'parent.a.c=c&parent.a.d=d&parent.b=b&');
    });

    test('evt validateData test - invalid key name', function () {
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                advertiserId: '123458987',
                tagId: 'abcde'
            };
            window.uet = new UET(initData);

            var invDiv = uet.createInvisibleDiv(document.getElementById('qunit-fixture'));
            var id = new Date().getTime();
            try {
                uet.evt('pageLoad', 'page_view', { 'evasd': id });
            } catch (err) {
                ok(true);
            }

            expect(1);
        }
    });

    test('evt validateData test - ev with string value', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                advertiserId: datetime,
                tagId: 'abcde'
            };
            window.uet = new UET(initData);

            var invDiv = uet.createInvisibleDiv(document.getElementById('qunit-fixture'));
            var id = new Date().getTime();
            try {
                uet.evt('pageLoad', 'page_view', { 'ev': 'foo' });
            } catch (err) {
                ok(true);
            }

            expect(1);
        }
    });

    test('evt retail vertical tests - valid prodids and pagetypes', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            expect(36);

            var initData = {
                adv: datetime,
                tagId: 'abcde',
                Sig: 'goo',
                debug: { CORS: true },
            };
            window.uet = new UET(initData);
            var prodid = '0123456789abcdef0123456789abcdef0123456789abcdef01';
            var pagetypes = ['home', 'searchresults', 'category', 'product', 'cart', 'purchase', 'other'];

            pagetypes.forEach(function(pagetype) {
                var pdata = { 'pagetype': pagetype, 'prodid': prodid, 'gv': 123, 'gc': 'CNY' };
                uet.evt('custom', null, pdata);

                assert.ok(pdata.hasOwnProperty('pagetype') === true && pdata.pagetype === pagetype, 'pagetype parameter should be set. Actual value: ' + pdata.pagetype);
                assert.ok(pdata.hasOwnProperty('prodid') === true && pdata.prodid === prodid, 'prodid parameter should be set. Actual value: ' + pdata.prodid);
                assert.ok(pdata.hasOwnProperty('gv') === true && pdata.gv === 123, 'gv parameter should be set. Actual value: ' + pdata.gv);
                assert.ok(pdata.hasOwnProperty('gc') === true && pdata.gc === 'CNY', 'gc parameter should be set. Actual value: ' + pdata.gc);
            })

            var pdata = {
                'pagetype': pagetypes[1],
                'prodid': [prodid, 'abc123', 987],
                'gv': 99.2,
                'gc': 'USD'
            };
            uet.evt('custom', null, pdata);

            assert.ok(pdata.hasOwnProperty('pagetype') === true && pdata.pagetype === pagetypes[1], 'pagetype parameter should be set. Actual value: ' + pdata.pagetype);
            assert.ok(pdata.hasOwnProperty('prodid') === true && pdata.prodid === '0123456789abcdef0123456789abcdef0123456789abcdef01,abc123,987', 'prodid parameter should be set. Actual value: ' + pdata.prodid);
            assert.ok(pdata.hasOwnProperty('gv') === true && pdata.gv === 99.2, 'gv parameter should be set. Actual value: ' + pdata.gv);
            assert.ok(pdata.hasOwnProperty('gc') === true && pdata.gc === 'USD', 'gc parameter should be set. Actual value: ' + pdata.gc);

            pdata = {
                'pagetype': pagetypes[2],
                'prodid': [undefined, prodid, null, 'abc123', , , 987],
                'gv': 99999.88,
                'gc': 'CNY'
            };
            uet.evt('custom', null, pdata);

            assert.ok(pdata.hasOwnProperty('pagetype') === true && pdata.pagetype === pagetypes[2], 'pagetype parameter should be set. Actual value: ' + pdata.pagetype);
            assert.ok(pdata.hasOwnProperty('prodid') === true && pdata.prodid === '0123456789abcdef0123456789abcdef0123456789abcdef01,abc123,987', 'prodid parameter should be set. Actual value: ' + pdata.prodid);
            assert.ok(pdata.hasOwnProperty('gv') === true && pdata.gv === 99999.88, 'gv parameter should be set. Actual value: ' + pdata.gv);
            assert.ok(pdata.hasOwnProperty('gc') === true && pdata.gc === 'CNY', 'gc parameter should be set. Actual value: ' + pdata.gc);
        }
    });

    test('evt pageload test - v2 - img', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        var ff = isFireFox();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                adv: datetime,
                tagId: 'abcde',
                debug: { CORS: false }
            };
            if (ff) {
                initData.debug.protocol = 'http:';
            }

            window.uet = new UET(initData);

            var parentNode = document.getElementById('qunit-fixture');
            var divs = parentNode.childElementCount;
            var invDiv = uet.createInvisibleDiv(parentNode);
            uet.evt('pageLoad', 'page_view', {});

            var elems = document.getElementById(invDiv).childNodes;

            for (var i = 0; i < elems.length; i++) {
                if (elems[i].src && (elems[i].src.indexOf('//bat.bing.com/action/0') > 0 || elems[i].src.indexOf('//bat.r.msn.com/action-uic/0') > 0)) {
                    ok(true);
                }
            }
            expect(elems.length);
        }
    });

    test('evt params - NavigatedFromURL and PageURL parameters', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                adv: datetime,
                tagId: 'abcde',
                Sig: 'goo',
                debug: { CORS: true },
            };
            window.uet = new UET(initData);
            var pdata = {};
            uet.evt('pageLoad', 'page_view', pdata);

            if (ie && ie >= 9 || ie === false) {
                expect(6);
                assert.ok(window.location.href.indexOf('batTests.htm') > -1, 'Window location contains batTests.htm');
            }
            else {
                expect(5);
            }

            assert.ok(pdata.hasOwnProperty('ifm') === false, 'ifm parameter is not set.');
            assert.ok(pdata.hasOwnProperty('r') === true && pdata.r === '', 'NavigatedFromURL parameter is set and empty.');
            assert.ok(pdata.hasOwnProperty('p') === true, 'PageURL parameter is set.');
            assert.ok(pdata.hasOwnProperty('r') === pdata.hasOwnProperty('p'), 'Both NavigatedFromURL and PageURL are present.');
            assert.ok(pdata.p === encodeURIComponent(window.location.href), 'PageURL and encoded window.location.href are same.');
        }
    });

    test('Snippet version compatibility test', function () {

        function checkBeaconUrl(imgSrc, initData, advertiserId) {
            if (initData.Ver === 2) {
                advertiserId = 0;
            }

            var params = uet.removeTrailingAmp(uet.stringifyToRequest(initData));
            var batUrl = '//bat.bing.com/action/' + advertiserId + '?' + params;
            var rbatUrl = '//bat.r.msn.com/action-uic/' + advertiserId + '?' + params;

            if (imgSrc.indexOf(batUrl) > 0 || imgSrc.indexOf(rbatUrl) > 0) {
                return true;
            }
            return false;
        }

        var datetime = new Date().getTime();
        var ie = isIE();
        var ff = isFireFox();
        if (ie && ie < 9) {
            expect(0);
        } else {
            // Format: advertiserId, tagId, Tag, Sig, Ver, EXT_Data, useTi, expectedResult, testMsg
            // NOTE: adding 'ti' will result in changing tagId to ti in initData
            var totalDataFields = 6;
            var tests = [
                ['375808', '209', 'TestTag', '0b9ec', '1', 'atc0.VALUE0/atc1.VALUE1', false, true, 'Version 1 tag'],
                ['375808', '209', 'TestTag',      '', '1', 'atc0.VALUE0/atc1.VALUE1', false, true, 'Version 1 tag without sig'],
                ['375808', '209', 'TestTag',      '',  '', 'atc0.VALUE0/atc1.VALUE1', false, true, 'Version 1 tag without sig and ver'],
                ['375808', '209', 'TestTag', '0b9ec', '2', 'atc0.VALUE0/atc1.VALUE1',  true, true, 'Version 1 tag']];

            var totalCases = 0;
            for (var i = 0; i < tests.length; i++) {
                var d = tests[i];
                var advertiserId = d[0];
                var useTi = d[6];
                var result = d[7];
                var testmsg = d[8];

                var initData = {
                    advertiserId: d[0],
                    tagId: d[1],
                    Tag: d[2],
                    Sig: d[3],
                    Ver: d[4],
                    EXT_Data: d[5],
                    debug: { CORS: false, formOnly: false }
                };
                if (ff) {
                    initData.debug.protocol = 'http:';
                }
                var keys = Object.keys(initData);

                for (var k=0; k < keys.length; k++) {
                    var key = keys[k];
                    if (initData.key === '') {
                        delete initData.key;
                    }
                }
                if (initData.Ver === '2') {
                    initData.q = [];
                }

                var parentNode = document.getElementById('qunit-fixture');
                var divs = parentNode.childElementCount;
                window.uet = new UET(initData);
                var invDiv = uet.createInvisibleDiv(parentNode);

                uet.evt('pageLoad', 'page_view', {});

                var elems = document.getElementById(invDiv).childNodes;
                totalCases += elems.length;

                for (var l = 0; l < elems.length; l++) {
                    assert.ok(checkBeaconUrl(elems[l].src, window.uet.beaconParams, advertiserId) === result, testmsg);
                }
            }

            assert.ok(totalCases > 0, 'Total test cases executed is not zero.');
            expect(totalCases+1);
        }
    });

    test('evt params - html encode test', function () {
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                ti: '5527558'
            };
            window.document.title = '#and&';
            window.uet = new UET(initData);
            var returnedData = uet.addPageData(initData);
            assert.ok(returnedData.tl === '%23and%26', 'Encoding test tl');
            expect(1);
        }
    });

    test('setCookie getCookie tests', function () {
        window.uet = new UET({});

        // Test #1: setCookie getCookie test for MS Click Id - setting 32-byte msclkid should succeed
        var result = verifyCookie(
            uet,
            '_uetclkidut',                        // msclkidCookieName
            10,                                   // msclkidCookieExpirationTime
            '_uet',                               // msclkidCookieValuePrefix
            32,                                   // msclkidCookieValueMaxLength
            true,                                 // Try to delete and then set cookie
            'cdd4afcccb1c9a4cad9544dd7e5006d6'    // Valid msclkid
        );

        assert.ok(result, 'setCookie getCookie test for MS Click Id - setting 32-byte msclkid should succeed: cookie set and got correctly.');

        // Remove the cookie to clean up
        removeCookie(uet, '_uetclkidut');

        // Test #2: setCookie getCookie test for MS Click Id - setting 35-byte msclkid should fail
        var result = verifyCookie(
            uet,
            '_uetclkidut',                        // msclkidCookieName
            10,                                   // msclkidCookieExpirationTime
            '_uet',                               // msclkidCookieValuePrefix
            32,                                   // msclkidCookieValueMaxLength
            true,                                 // Try to delete and then set cookie
            'cdd4afcccb1c9a4cad9544dd7e5006d6000' // Invalid msclkid (too long)
        );

        assert.ok(!result, 'setCookie getCookie test for MS Click Id - setting 35-byte msclkid should fail: cookie should not be got.');

        // Remove the cookie to clean up
        removeCookie(uet, '_uetclkidut');

        expect(2);
    });

    test('evt params - MS Click Id parameter test without msclkid from URL', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                ti: '5527558'
            };
            window.uet = new UET(initData);

            // Remove the cookie to prepare a clean cookie environment
            removeCookie(uet, '_uetmsclkid');

            var pdata = {};
            uet.evt('pageLoad', 'page_view', pdata);

            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 1st event.');
            assert.ok(pdata.msclkid === 'N', 'msclkid parameter in the 1st event should be N. Actual: ' + pdata.msclkid);

            var id = new Date().getDate();
            pdata = { 'ev': id };
            uet.evt('custom', null, pdata);

            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 2nd event.');
            assert.ok(pdata.msclkid === 'N', 'msclkid parameter in the 2nd event should also be N. Actual: ' + pdata.msclkid);

            expect(4);
        }
    });

    test('evt params - MS Click Id parameter test with msclkid provided from URL', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var msclkid1 = 'cdd4afcccb1c9a4cad9544dd7e5006d5',
                msclkid2 = '55cc00ff55cc00ff55cc00ff55cc00ff',
                initData = {
                    ti: '5527558'
                };

            window.uet = new UET(initData);

            // Test #1: no msclkid in cookie, msclkid exists in URL
            // Inject the msclkid value via mocked URL1
            uet.extractMsClkId({ p: 'batTests.html?msclkid=' + msclkid1 });

            var pdata = {};
            uet.evt('pageLoad', 'page_view', pdata);

            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 1st event.');
            assert.ok(pdata.msclkid === msclkid1 + '-1', 'msclkid parameter in the 1st event should be the same as provided in URL, plus indicator of a new msclkid. Actual: ' + pdata.msclkid);

            // Test #2: msclkid exists cookie, same msclkid exists in URL
            var id = new Date().getDate();
            pdata = { 'ev': id };
            uet.evt('custom', null, pdata);

            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 2nd event.');
            assert.ok(pdata.msclkid === msclkid1 + '-0', 'msclkid parameter in 2nd event should have same msclkid as the 1st but with suffix set to 0. Actual: ' + pdata.msclkid);

            // Test #3: msclkid exists in cookie, no msclkid from URL
            // Remove msClkId from uet object
            window.uet = new UET(initData);

            id = new Date().getDate();
            pdata = { 'ev': id };
            uet.evt('custom', null, pdata);

            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 2nd event.');
            assert.ok(pdata.msclkid === msclkid1 + '-0', 'msclkid parameter in 3rd event has same msclkid as the 1st but with suffix set to 0. Actual: ' + pdata.msclkid);

            // Test #4: msclkid exists in URL, and is different from msclkid in cookie
            window.uet = new UET(initData);;
            // Inject the msclkid value via mocked URL2
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid2 });

            id = new Date().getDate();
            pdata = { 'ev': id };
            uet.evt('custom', null, pdata);

            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 2nd event.');
            assert.ok(pdata.msclkid === msclkid2 + '-1', 'msclkid parameter in 4th event has same msclkid as provided in URL2, plus indicator of a new msclkid. Actual: ' + pdata.msclkid);

            // Remove the cookie to clean up
            removeCookie(uet, '_uetmsclkid');

            expect(8);
        }
    });

    test('getQueryParam tests', function () {
        window.uet = new UET({});

        var msclkid = 'cdd4afcccb1c9a4cad9544dd7e5006d5',
            testcases = [
                // [URL-values, should-be-found-or-not]
                // Normal cases
                ['http://contoso.com/batTests.html?msclkid=' + msclkid,                        true],  // 1 parameter, found
                ['http://contoso.com/batTests.html?paramA=' + msclkid,                        false],  // 1 parameter, not found
                ['http://contoso.com/batTests.html?msclkid=' + msclkid + '&paramA=a',          true],  // 2 parameters, found at 1st place
                ['http://contoso.com/batTests.html?paramA=a&msclkid=' + msclkid,               true],  // 2 parameters, found at 2nd place
                ['http://contoso.com/batTests.html?paramA=a&paramB=' + msclkid,               false],  // 2 parameters, not found
                ['http://contoso.com/batTests.html?msclkid=' + msclkid + '&paramA=a&paramB=b', true],  // 3 parameters, found at 1st place
                ['http://contoso.com/batTests.html?paramA=a&msclkid=' + msclkid + '&paramB=b', true],  // 3 parameters, found at 2nd place
                ['http://contoso.com/batTests.html?paramA=a&paramB=' + msclkid + '&paramB=b', false],  // 3 parameters, not found
                ['http://contoso.com/batTests.html?paramA=a&msclkid=' + msclkid + '#a/b',      true],  // Multiple parameters with hash, found at middle
                ['http://contoso.com/batTests.html?paramA=a&paramB=' + msclkid + '#a/b',      false],  // Multiple parameters with hash, not found
                ['https://a@b.com/b_%20c/d.e?a.c[1]=a&msclkid=' + msclkid + '#a/&lt;b[2]/$c',  true],  // Complex URL, found at middle
                // Error Cases
                ['`~!@#$%^&*()-=_+[]{}|,./<>?;:\'"\\',                                        false],  // Random string
                [null,                                                                        false],
                [undefined,                                                                   false],
                ['',                                                                          false],  // Empty string
                [999,                                                                         false],  // Not a string - Number case
                [[1, '2', 3],                                                                 false],  // Not a string - Array case
                [{ a:1, b:2 },                                                                false],  // Not a string - Object case
                [function () { return 1; },                                                   false]   // Not a string - Function case
            ],
            paramNames = [
                ['msclkid',                                                                    true],
                ['paramC',                                                                    false],
                ['param2',                                                                    false],
                ['b[2]',                                                                      false],
                ['`~!@#$%^&*()-=_+[]{}|,./<>?;:\'"\\',                                        false],
                [null,                                                                        false],
                [undefined,                                                                   false],
                ['',                                                                          false],
                [999,                                                                         false],
                [[1, '2', 3],                                                                 false],
                [{ a:1, b:2 },                                                                false],
                [function () { return 1; },                                                   false]
            ];

        testcases.forEach(function (testcase) {
            paramNames.forEach(function (paramName) {
                var expected = testcase[1] && paramName[1],
                    retVal = uet.getQueryParam(testcase[0], paramName[0]);

                assert.ok(
                    (retVal === msclkid) === expected,
                    'Parameter "' + paramName[0] + '" should ' + (expected ? '' : 'not') + ' be found for URL "' + testcase[0] + '". Actual return value: ' + retVal
                );
            });
        });

        // Edge cases
        var retVal = uet.getQueryParam('https://a@b.com/b_%20c/d.e?a.c[1]=a&msclkid=cdd4afcccb1c9a4cad9544dd7e5006d5#a/&lt;b[2]/$c', 'a.c[1]');
        assert.ok(
            retVal === null,
            'Parameter "a.c[1]" should not be found for URL "https://a@b.com/b_%20c/d.e?a.c[1]=a&msclkid=cdd4afcccb1c9a4cad9544dd7e5006d5#a/&lt;b[2]/$c" because the parameter name is not allowed. Actual: ' + retVal
        );

        retVal = uet.getQueryParam('https://a@b.com/b_%20c/d.e?abc1=z1&msclkid=cdd4afcccb1c9a4cad9544dd7e5006d5#a/&lt;b[2]/$c', 'abc1');
        assert.ok(
            retVal === 'z1',
            'Parameter "abc1" should be found for URL "https://a@b.com/b_%20c/d.e?abc1=z1&msclkid=cdd4afcccb1c9a4cad9544dd7e5006d5#a/&lt;b[2]/$c" because the parameter name is allowed. Actual: ' + retVal
        );

        expect(testcases.length * paramNames.length + 2);
    });

    test('evt params - No repeated parameters', function () {
        function hasDuplicateParams(imgSrc) {
            var keys = {};
            var tokens = imgSrc.split('?');
            if (tokens.length === 2) {
                var params = tokens[1].split('&');
                for (var i = 0; i < params.length; i++) {
                    var key = params[i].split('=')[0];
                    if (keys.hasOwnProperty(key) === true) {
                        console.log('Paramater appears more than once in url. Parameter key:' + key);
                        console.log('image src:' + imgSrc);
                        return true;
                    }
                    keys[key] = 1;
                }
                return false;
            }
            return true;
        }

        var datetime = new Date().getTime();
        var ie = isIE();
        var ff = isFireFox();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                adv: datetime,
                tagId: 'abcde',
                debug: { CORS: false, formOnly: false, r: 'example.com/test.html' }
            };
            if (ff) {
                initData.debug.protocol = 'http:';
            }

            window.uet = new UET(initData);

            var parentNode = document.getElementById('qunit-fixture');
            var divs = parentNode.childElementCount;
            var invDiv = uet.createInvisibleDiv(parentNode);
            var id = new Date().getDate();
            uet.evt('pageLoad', 'page_view', {});

            var elems = document.getElementById(invDiv).childNodes;

            for (var i = 0; i < elems.length; i++) {
                if (elems[i].src && (elems[i].src.indexOf('//bat.bing.com/action/0') > 0 || elems[i].src.indexOf('//bat.r.msn.com/action-uic/0') > 0)) {
                    ok(hasDuplicateParams(elems[i].src) === false, 'Url does not contain duplicate parameters');
                }
            }
            expect(elems.length);
        }
    });

    test('addUrlData test - in top page', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                ti: '5527558'
            },
            pdata = {};

            window.uet = new UET(initData);

            // Get p and r parameters
            pdata = uet.addUrlData(pdata);

            assert.ok(pdata.hasOwnProperty('p') === true, 'p parameter is set.');
            assert.ok(pdata.p.indexOf('2Fqunit%2FbatTests.htm') >= 0, 'p parameter should be the local path of the test page. Actual: ' + pdata.p);
            assert.ok(pdata.hasOwnProperty('r') === true, 'r parameter is set.');
            assert.ok(pdata.r === '', 'r parameter should be empty. Actual: ' + pdata.r);

            expect(4);
        }
    });

    test('extractMsClkId tests', function () {
        var msclkid1 = 'cdd4afcccb1c9a4cad9544dd7e5006d5',
            msclkid2 = '12345678901234567890123456789012',
            initData = {
                ti: '5527558'
            };
        window.uet = new UET(initData);

        // Attempt to extract for the 1st time (using the 1st URL)
        uet.extractMsClkId({ p: 'batTests.html?msclkid=' + msclkid1 });

        assert.ok(uet.hasOwnProperty('msClkId') === true, 'msClkId exists on uet object.');
        assert.ok(uet.msClkId === msclkid1, 'msClkId is the same as provided in the 1st URL after extracting from it. Actual: ' + uet.msClkId);

        // Attempt to extract for the 2nd time (using the 2nd URL)
        uet.extractMsClkId({ p: 'batTests.html?msclkid=' + msclkid2 });

        assert.ok(uet.hasOwnProperty('msClkId') === true, 'msClkId exists on uet object.');
        assert.ok(uet.msClkId === msclkid1, 'msClkId is still the same as provided in the 1st URL after attempting to extract again from 2nd URL. Actual: ' + uet.msClkId);

        expect(4);
    });

    test('addMsClkId tests', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var msclkid1 = '0123456789abcdef0123456789abcdef',
                msclkid2 = '12345678901234567890123456789012',
                initData = {
                    ti: '5527558'
                };

            window.uet = new UET(initData);

            // Test #1: No msclkid in cookie, no msclkid from URL
            // First remove the cookie to prepare a clean cookie environment
            // uet.msClkId is null on initialization
            removeCookie(uet, '_uetmsclkid');

            var pdata = {};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 1st event.');
            assert.ok(pdata.msclkid === 'N', 'msclkid parameter in the 1st event is "N". Actual: ' + pdata.msclkid);

            // Test #2: No msclkid in cookie, msclkid exists in URL
            // Inject the msclkid value via mocked URL1
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid1 });

            pdata = {};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 2nd event.');
            assert.ok(pdata.msclkid === msclkid1 + '-1', 'msclkid parameter in the 2nd event is the same as provided in URL1, plus indicator of a new msclkid. Actual: ' + pdata.msclkid);

            // Test #3: msclkid exists in URL, and is the same as msclkid in cookie
            pdata = { 'ev': '12345'};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 3rd event.');
            assert.ok(pdata.msclkid === msclkid1 + '-0', 'msclkid parameter in 3rd event has same msclkid as the 2nd but with suffix set to 0. Actual: ' + pdata.msclkid);

            // Test #4: msclkid exists in cookie, no msclkid from URL
            // Remove msClkId from uet object
            window.uet = new UET(initData);
            pdata = { 'ev': '12345'};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 4th event.');
            assert.ok(pdata.msclkid === msclkid1 + '-0', 'msclkid parameter in 4th event has same msclkid as the 2nd but with suffix set to 0. Actual: ' + pdata.msclkid);

            // Test #5: msclkid exists in URL, and is different from msclkid in cookie
            window.uet = new UET(initData);
            // Inject the msclkid value via mocked URL2
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid2 });

            pdata = { 'ev': '99999'};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 5th event.');
            assert.ok(pdata.msclkid === msclkid2 + '-1', 'msclkid parameter in 5th event has same msclkid as provided in URL2, plus indicator of a new msclkid. Actual: ' + pdata.msclkid);

            // Remove the cookie to clean up
            removeCookie(uet, '_uetmsclkid');

            expect(10);
        }
    });

    test('addMsClkId negative tests', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var msclkid1 = '',                                  // empty
                msclkid2 = '123456789012345678901234567890120', // too long (33 bytes)
                msclkid3 = '0123456789abcdef0123456789abcdef',  // valid
                initData = {
                    ti: '5527558'
                };

            window.uet = new UET(initData);
            // Inject the msclkid value via mocked URL1
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid1 });

            // First remove the cookie to prepare a clean cookie environment
            // uet.msClkId is null on initialization
            removeCookie(uet, '_uetmsclkid');

            // Test #1: No msclkid in cookie, empty msclkid from URL
            var pdata = {};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 1st event.');
            assert.ok(pdata.msclkid === 'N', 'msclkid parameter in 1st event is "N" since the msclkid provided in URL1 is an empty string. Actual: ' + pdata.msclkid);
            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === null,
                '_uetmsclkid cookie should not be set.'
            );

            // Test #2: No msclkid in cookie, msclkid exists in URL and is too long
            window.uet = new UET(initData);
            // Inject the msclkid value via mocked URL2
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid2 });

            pdata = { 'ev': '99999'};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 2nd event.');
            assert.ok(pdata.msclkid === msclkid2 + '-1N', 'msclkid parameter in 2nd event is the too-long msclkid from URL plus "-1N" since the msclkid provided in URL2 is too long,  Actual: ' + pdata.msclkid);
            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === null,
                '_uetmsclkid cookie should not be set.'
            );

            // Test #3: No msclkid in cookie, msclkid exists in URL
            window.uet = new UET(initData);
            // Inject the msclkid value via mocked URL1
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid3 });

            pdata = {};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 3rd event.');
            assert.ok(pdata.msclkid === msclkid3 + '-1', 'msclkid parameter in the 3rd event is the same as provided in URL3, plus indicator of a new msclkid. Actual: ' + pdata.msclkid);
            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid3,
                '_uetmsclkid cookie should be set with URL3. Actual: ' + uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */)
            );

            // Test #4: msclkid exists in cookie, empty msclkid from URL
            window.uet = new UET(initData);
            // Inject the msclkid value via mocked URL1
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid1 });

            pdata = {};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 4th event.');
            assert.ok(pdata.msclkid === msclkid3 + '-0', 'msclkid parameter in 4th event is the same as the msclkid stored in cookie plus "-0", since the one provided in URL1 is an empty string. Actual: ' + pdata.msclkid);
            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid3,
                '_uetmsclkid cookie should be still the one from URL3. Actual: ' + uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */)
            );

            // Test #5: msclkid exists in cookie, msclkid exists in URL and is too long
            // This one is special - the one sent is the one in URL, but not set to cookie since it's too long
            window.uet = new UET(initData);
            // Inject the msclkid value via mocked URL2
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid2 });

            pdata = { 'ev': '99999'};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 5th event.');
            assert.ok(pdata.msclkid === msclkid2 + '-1N', 'msclkid parameter in 5th event is the too-long msclkid from URL plus "-1N" since the msclkid provided in URL2 is too long,  Actual: ' + pdata.msclkid);
            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid3,
                '_uetmsclkid cookie should be still the one from URL3. Actual: ' + uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */)
            );

            // Test #6: msclkid exists in cookie, no msclkid in URL
            window.uet = new UET(initData);
            pdata = { 'ev': '99999'};
            pdata = uet.addMsClkId(pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 6th event.');
            assert.ok(pdata.msclkid === msclkid3 + '-0', 'msclkid parameter in 6th event is the previous msclkid stored in cookie plus "-0" since no msclkid is provided in URL,  Actual: ' + pdata.msclkid);
            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid3,
                '_uetmsclkid cookie should be still the one from URL3. Actual: ' + uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */)
            );

            // Remove the cookie to clean up
            removeCookie(uet, '_uetmsclkid');

            expect(18);
        }
    });

    test('first-party cookie opt-out tests for evt', function () {
        var datetime = new Date().getTime();
        var ie = isIE();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var msclkid1 = '0123456789abcdef0123456789abcdef',
                msclkid2 = '12345678901234567890123456789012',
                initData = {
                    ti: '5527558',
                    storeConvTrackCookies:false // opt out for 1st-party cookie related features
                };

            window.uet = new UET(initData);

            // Test #1: No msclkid in cookie, no msclkid from URL
            // First remove the cookie to prepare a clean cookie environment
            // uet.msClkId is null on initialization
            removeCookie(uet, '_uetmsclkid');

            var pdata = {};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === false, 'msclkid parameter is not set for 1st event.');
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === null,
                '_uetmsclkid cookie should not be set.'
            );

            // Test #2: No msclkid in cookie, msclkid exists in URL
            // Inject the msclkid value via mocked URL1
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid1 });

            pdata = {};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === false, 'msclkid parameter is not set for 2nd event.');
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === null,
                '_uetmsclkid cookie should not be set.'
            );

            // Test #3: msclkid exists in URL, and is the same as msclkid in cookie
            pdata = { 'ev': '12345'};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === false, 'msclkid parameter is not set for 3rd event.');
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === null,
                '_uetmsclkid cookie should not be set.'
            );

            // Test #4: NO OPT-OUT: msclkid exists in cookie, no msclkid from URL
            // Remove msClkId from uet object
            initData = {
                ti: '5527558' // Do not opt out for 1st-party cookie related features
            };
            window.uet = new UET(initData);
            pdata = { 'ev': '12345'};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 4th event.');
            assert.ok(pdata.msclkid === 'N', 'msclkid parameter in 4th event should be "N". Actual: ' + pdata.msclkid);
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === null,
                '_uetmsclkid cookie should not be set.'
            );

            // Test #5: NO OPT-OUT: msclkid exists in URL, and is different from msclkid in cookie
            initData = {
                ti: '5527558',
                storeConvTrackCookies:123 // Do not opt out for 1st-party cookie related features
            };
            window.uet = new UET(initData);
            // Inject the msclkid value via mocked URL2
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid2 });

            pdata = { 'ev': '99999'};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === true, 'msclkid parameter is set for 5th event.');
            assert.ok(pdata.msclkid === msclkid2 + '-1', 'msclkid parameter in 5th event has same msclkid as provided in URL2, plus indicator of a new msclkid. Actual: ' + pdata.msclkid);
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid2,
                '_uetmsclkid cookie should be set.'
            );

            // Test #6: Existing msclkid in cookie, no msclkid from URL
            // uet.msClkId is null on initialization
            initData = {
                ti: '5527558',
                storeConvTrackCookies:false // opt out for 1st-party cookie related features
            };
            window.uet = new UET(initData);

            pdata = {};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === false, 'msclkid parameter is not set for 6th event.');
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid2,
                '_uetmsclkid cookie should still be there.'
            );

            // Test #7: Existing msclkid in cookie, msclkid exists in URL
            // Inject the msclkid value via mocked URL1
            uet.extractMsClkId({ p: 'http://contoso.com/unittests/batTests.html?paramA1=a1&msclkid=' + msclkid1 });

            pdata = {};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === false, 'msclkid parameter is not set for 7th event.');
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid2,
                '_uetmsclkid cookie should still be there.'
            );

            // Test #8: msclkid exists in URL, and is the same as msclkid in cookie
            pdata = { 'ev': '12345'};
            // Using evt() directly instead of pdata = uet.addMsClkId(pdata);
            uet.evt('custom', null, pdata);
            assert.ok(pdata.hasOwnProperty('msclkid') === false, 'msclkid parameter is not set for 8th event.');
            assert.ok(pdata.hasOwnProperty('storeConvTrackCookies') === false, 'storeConvTrackCookies parameter is not set for any event.');

            assert.ok(
                uet.getCookie('_uetmsclkid' /* cookieName */, '_uet' /* prefix */, 128 /* max-length */) === msclkid2,
                '_uetmsclkid cookie should still be there.'
            );

            // Remove the cookie to clean up
            removeCookie(uet, '_uetmsclkid');

            expect(26);
        }
    });
}());