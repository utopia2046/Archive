/*global module, microsoft*/
(function () {
    'use strict';

    function isIE() {
        var myNav = navigator.userAgent.toLowerCase();
        return (myNav.indexOf('msie') !== -1) ? parseInt(myNav.split('msie')[1]) : false;
    }

    function isFireFox() {
        var myNav = navigator.userAgent.toLowerCase();
        return (myNav.indexOf('firefox') !== -1) ? true : false;
    }

    module('BAT', {
        setup: function () {
            /*
              Any data that is required for initialization of the library.
              This will typically include any fields that need to be sent with every G call
            */
            var initData = {
                advertiserId: '12345',
                tagId: 'abcde',
                Ver: '1'
            }

            /*
               Initialize the UET object
            */
            window.uet = new UET(initData);
            XMLHttpRequest.calls = {};

        },
        teardown: function () {
            window.uet = null;
            XMLHttpRequest.calls = {};
        }
    });

    test('iframe - NavigatedFromURL and PageURL parameters', function () {
        var datetime = new Date().getTime();
        var initData = {
            adv: datetime,
            tagId: 'abcde',
            Sig: 'goo',
            Ver: 1
        }
        window.uet = new UET(initData);
        var pdata = {};
        uet.evt('pageLoad', 'page_view', pdata);

        assert.ok(window.self != window.top, 'iframe detected.');
        assert.ok(window.location.href.indexOf('iframeBatTests.htm') > -1, 'Window location contains iframeBatTests.htm');
        assert.ok(pdata.hasOwnProperty('ifm') === true && pdata.ifm === 1, 'ifm parameter found and set to 1.');
        if (window.location.protocol === 'file:') {
            assert.ok(pdata.hasOwnProperty('r') === false, 'NavigatedFromURL parameter is not set.');
            assert.ok(pdata.hasOwnProperty('p') === false, 'PageURL parameter is not set.');
            assert.ok(pdata.hasOwnProperty('r') === pdata.hasOwnProperty('p'), 'NavigatedFromURL and PageURL are both present.');
            assert.ok(pdata.r === pdata.p, 'NavigatedFromURL and PageURL are same.');
            expect(7);
        } else {
            assert.ok(pdata.hasOwnProperty('r') === true, 'NavigatedFromURL parameter should be set on http & https.');
            assert.ok(pdata.hasOwnProperty('p') === true, 'PageURL parameter should be set on http & https.');
            expect(5);
        }
    });

    test('iframe - No repeated parameters', function () {
        function hasDuplicateParams(imgSrc) {
            var keys = {};
            var tokens = imgSrc.split('?');
            if (tokens.length === 2) {
                var params = tokens[1].split('&');
                for (var i = 0; i < params.length; i++) {
                    var key = params[i].split('=')[0];
                    if (keys.hasOwnProperty(key) === true) {
                        console.log('Paramater appears more than once in url. Parameter key:' + key);
                        console.log('image src:' + imgSrc);
                        return true;
                    }
                    keys[key] = 1;
                }
                return false;
            }
            return true;
        }

        var datetime = new Date().getTime();
        var ie = isIE();
        var ff = isFireFox();
        if (ie && ie < 9) {
            expect(0);
        } else {
            var initData = {
                adv: datetime,
                tagId: 'abcde',
                debug: { CORS: false, formOnly: false, r: 'example.com/test.html' }
            };
            if (ff) {
                initData.debug.protocol = 'http:';
            }

            window.uet = new UET(initData);

            var parentNode = document.getElementById('qunit-fixture');
            var divs = parentNode.childElementCount;
            var invDiv = uet.createInvisibleDiv(parentNode);
            uet.evt('pageLoad', 'page_view', {});

            var elems = document.getElementById(invDiv).childNodes;

            for (var i = 0; i < elems.length; i++) {
                if (elems[i].src && (elems[i].src.indexOf('//bat.bing.com/action/0') > 0 || elems[i].src.indexOf('//bat.r.msn.com/action-uic/0') > 0)) {
                    ok(hasDuplicateParams(elems[i].src) === false, 'Url does not contain duplicate parameters');
                }
            }
            expect(elems.length);
        }
    });

}());