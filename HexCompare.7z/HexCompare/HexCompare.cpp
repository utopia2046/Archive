// HexCompare.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
	int iSampleValue = -32767 - 32767;
	unsigned char* pBuffer = new unsigned char[16];
	short* pBuf = (short* )pBuffer;

    if (iSampleValue > 0x7FFF)
    {
        iSampleValue = 0x7FFF;
    }

    if (iSampleValue < -0x7FFF)
    {
        iSampleValue = -0x7FFF;
    }

	*pBuf = (short)iSampleValue;

	if (pBuffer != NULL ) delete[] pBuffer;

	return 0;
}

