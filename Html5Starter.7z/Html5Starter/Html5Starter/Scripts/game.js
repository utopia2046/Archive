﻿/// <reference path="jquery-2.0.3.intellisense.js" />

// Initialize canvas and load image
var canvasWidth = 800;
var canvasHeight = 600;
$('#gameCanvas').attr('width', canvasWidth);
$('#gameCanvas').attr('height', canvasHeight);
var canvas = $('#gameCanvas')[0].getContext('2d');
canvas.strokeRect(0, 0, canvasWidth, canvasHeight);

var image = new Image();
image.src = "Images/outline-512.png";
var playerX = canvasWidth / 2 - image.width / 2;
var playerY = canvasHeight / 2 - image.height / 2;
$(image).load(function () {
    canvas.drawImage(image, playerX, playerY);
});

// Key pooling logic
var keysDown = {};

$('body').bind('keydown', function(e) {
    keysDown[e.which] = true;
});
$('body').bind('keyup', function (e) {
    keysDown[e.which] = false;
});

// Game loop
var FPS = 30;

setInterval(function () {
    update();
    draw();
}, 1000 / FPS);

function update()
{
    if (keysDown[37]) { //Left
        playerX -= 5;
    }
    if (keysDown[38]) { //Up
        playerY -= 5;
    }
    if (keysDown[39]) { //Right
        playerX += 5
    }
    if (keysDown[40]) { //Down
        playerY += 5;
    }
    playerX = clamp(playerX, 0, canvasWidth - image.width);
    playerY = clamp(playerY, 0, canvasHeight - image.height);
}

function clamp(x, min, max) {
    return x < min ? min : (x > max ? max : x);
}

function draw()
{
    canvas.clearRect(0, 0, canvasWidth, canvasHeight);
    canvas.drawImage(image, playerX, playerY);
}
