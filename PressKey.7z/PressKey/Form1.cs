﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PressKey
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.KeyDown += Form1_KeyDown;
            textBox1.KeyPress += Form1_KeyPress;
            textBox1.KeyUp += Form1_KeyUp;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            string message = "{KeyDown} ";
            message += "KeyCode = " + e.KeyCode.ToString();
            message += "; KeyData = " + e.KeyData.ToString();
            message += "; KeyValue = " + e.KeyValue.ToString();

            this.textBox1.Text += message + Environment.NewLine;
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            string message = "{KeyUp} ";
            message += "KeyChar = " + e.KeyChar.ToString();

            this.textBox1.Text += message + Environment.NewLine;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            string message = "{KeyUp} ";
            message += "KeyCode = " + e.KeyCode.ToString();
            message += "; KeyData = " + e.KeyData.ToString();
            message += "; KeyValue = " + e.KeyValue.ToString();

            this.textBox1.Text += message + Environment.NewLine;
        }
    }
}
