﻿namespace Microsoft.BingAds.Api.Model
{
    using System.Collections.Generic;

    public class MultiAccountDownloadTaskItem : TaskItem
    {
        private IEnumerable<string> accountNumbers = new List<string>();
        private IEnumerable<int> customerIds = new List<int>();
        private IEnumerable<EntityFilter> filters = new List<EntityFilter>();

        //public DownloadFilter DownloadFilter { get; set; }
        public FilterEntityType DownloadEntityTypes { get; set; }
        public DateRange DateRange { get; set; }
        public string AccountSearchCriteria { get; set; }  // To be used by UCM.

        public IEnumerable<string> AccountNumbers
        {
            get { return this.accountNumbers; }
            set { this.accountNumbers = value; }
        }

        public IEnumerable<int> CustomerIds
        {
            get { return this.customerIds; } 
            set { this.customerIds = value; }
        }

        public IEnumerable<EntityFilter> Filters
        {
            get { return this.filters; }
            set { this.filters = value; }
        }
    }
}
