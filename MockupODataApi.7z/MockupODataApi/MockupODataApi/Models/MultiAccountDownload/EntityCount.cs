﻿namespace Microsoft.BingAds.Api.Model
{
    public class EntityCount
    {
        public FilterEntityType Entity { get; set; }

        public int Count { get; set; }
    }
}
