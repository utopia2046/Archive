﻿
namespace Microsoft.BingAds.Api.Model.MultiAccountDownload
{
    using System.Collections.Generic;

    public class Filter : BaseExpression
    {
        public LogicalOperator LogicalOperator { get; set; }

        //Expression can be a Predicate Or Another Filter
        public IEnumerable<BaseExpression> Expressions
        {
            get { return this._expressions; } 
            set { this._expressions = value; }
        }

        private IEnumerable<BaseExpression> _expressions = new List<BaseExpression>();
    }
}
