﻿namespace Microsoft.BingAds.Api.Model
{
    using System.Collections.Generic;

    public class MultiAccountDownloadResult : TaskItemExecution
    {
        public string DownloadUrl { get; set; }
        public long FileSizeInBytes { get; set; }
        public IEnumerable<EntityCount> EntityCounts { get; set; }
        public IEnumerable<KeyValuePair<long,IEnumerable<AdsApiError>>> Errors { get; set; }
        public IEnumerable<long> AccountIdsProcessed { get; set; }
    }
}
