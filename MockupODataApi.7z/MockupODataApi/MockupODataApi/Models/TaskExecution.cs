﻿namespace Microsoft.BingAds.TaskEngine.ObjectModel
{
    using System;

    /// <summary>
    /// The TaskExecution interface.
    /// </summary>
    public class TaskExecution
    {
        /// <summary>
        /// Gets the id.
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the start time.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Task execution duration in seconds.
        /// </summary>
        public int DurationInSecs { get; set; }

        /// <summary>
        /// Gets or sets the task name.
        /// </summary>
        public string TaskName { get; set; }

        /// <summary>
        /// Gets or sets the task type.
        /// </summary>
        public int TaskType { get; set; }

        /// <summary>
        /// Gets or sets the task id.
        /// </summary>
        public long TaskId { get; set; }

        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        public RunResultState State { get; set; }

        /// <summary>
        /// Gets or sets the succes count.
        /// </summary>
        public int SuccesCount { get; set; }

        /// <summary>
        /// Gets or sets the failure count.
        /// </summary>
        public int FailureCount { get; set; }

        /// <summary>
        /// Gets or sets the last checkpoint. Blob 
        /// </summary> 
        public string LastCheckpoint { get; set; }
    }
}