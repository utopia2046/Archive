﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RunResultState.cs" company="Microsoft">
//   Copyright (c) Microsoft. All rights reserved.
// </copyright>
// <summary>
//   The run result state.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.BingAds.TaskEngine.ObjectModel
{
    public enum RunResultState
    {
        InProgress = 0,
        Completed = 1,
        Failed = 2,
        RetryNeeded = 3,
        PendingExecution = 4
    }
}