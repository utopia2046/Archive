﻿namespace Microsoft.BingAds.Api.Model
{
    public class User
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
