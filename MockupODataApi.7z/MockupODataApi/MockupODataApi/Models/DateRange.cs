﻿namespace Microsoft.BingAds.Api.Model
{
    using System;

    public class DateRange
    {
        public DateRangePreset? DateRangePreset { get; set; }
        public DateTimeOffset? StartDate { get; set; }
        public DateTimeOffset? EndDate { get; set; }
    }
}