﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Microsoft.BingAds.Api.Model;

namespace MockupODataApi.Models
{
    public class MockupODataApiDbContext : DbContext
    {
        public MockupODataApiDbContext() : base("name=MockupODataApiDB")
        {
        }

        public DbSet<MultiAccountDownloadTaskItem> TaskItems { get; set; }
    }
}