﻿
namespace Microsoft.BingAds.Api.Model
{
    using System.Collections.Generic;

    public class Filter : BaseExpression
    {
        public LogicalOperator LogicalOperator { get; set; }

        //Expression can be a Predicate Or Another Filter
        public IEnumerable<BaseExpression> Expressions { get; set; }

        public Filter()
        {
            this.Expressions = new List<BaseExpression>();
        }
    }
}
