﻿namespace Microsoft.BingAds.Api.Model
{
    public class EntityFilter
    {
        public FilterEntityType EntityType { get; set; }
        public Filter Filter { get; set; }
    }
}
