﻿namespace Microsoft.BingAds.Api.Model
{
    public abstract class BaseExpression
    {
    }
}
