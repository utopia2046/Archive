﻿namespace Microsoft.BingAds.Api.Model
{
    using System.Collections.Generic;

    public class Predicate : BaseExpression
    {
        public string PropertyName { get; set; }
        public Operator Operator { get; set; }
        public IEnumerable<string> Values { get; set; }
    }
}
