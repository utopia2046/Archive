﻿namespace Microsoft.BingAds.Api.Model
{
    using System.Collections.Generic;

    public class DownloadFilter
    {
        public EntityFilter EntityFilter { get; set; }
        //public IEnumerable<ChildEntityFilter> ChildEntityFilters { get; set; }
        //public IEnumerable<EntityFilter> ParentEntityFilters { get; set; }

        public DownloadFilter()
        {
            //ChildEntityFilters = new List<ChildEntityFilter>();
            //ParentEntityFilters = new List<EntityFilter>();
        }
    }
}
