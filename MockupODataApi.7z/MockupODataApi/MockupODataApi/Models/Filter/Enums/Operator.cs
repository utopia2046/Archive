﻿namespace Microsoft.BingAds.Api.Model
{
    public enum Operator
    {
        Equals,
        DoesNotEqual,
        Contains,
        DoesNotContain,
        BeginsWith,
        DoesNotBeginWith,
        EndsWith,
        DoesNotEndWith,
        IsEmpty,
        IsNotEmpty,
        GreaterThan,
        LessThan,
        GreaterThanEqual,
        LessThanEqual
    }
}
