﻿namespace Microsoft.BingAds.Api.Model
{
    public enum LogicalOperator
    {
        AND,
        OR
    }
}
