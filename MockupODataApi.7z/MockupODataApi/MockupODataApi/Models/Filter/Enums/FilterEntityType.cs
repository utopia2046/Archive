﻿namespace Microsoft.BingAds.Api.Model
{
    using System;

    [Flags]
    public enum FilterEntityType : long
    {
        CampaignNegativeKeywords = 1L << 0,
        AdGroupNegativeKeywords = 1L << 1,
        CampaignTargets = 1L << 2,
        AdGroupTargets = 1L << 3,
        CampaignNegativeSites = 1L << 4,
        AdGroupNegativeSites = 1L << 5,
        AdEditorialRejectionReasons = 1L << 6,
        KeywordEditorialRejectionReasons = 1L << 7,
        CampaignSiteLinksAdExtensions = 1L << 8,
        CampaignProductAdExtensions = 1L << 9,
        CampaignLocationAdExtensions = 1L << 10,
        CampaignCallAdExtensions = 1L << 11,
        AdGroupProductTargets = 1L << 12,
        ProductTargetEditorialRejectionReasons = 1L << 13,
        AdGroupSiteLinksAdExtensions = 1L << 14,
        Campaigns = 1L << 15,
        AdGroups = 1L << 16,
        Ads = 1L << 17,
        Keywords = 1L << 18,
        LocationAdExtensions = 1L << 19,
        CallAdExtensions = 1L << 20,
        SiteLinksAdExtensions = 1L << 21,
        ProductAdExtensions = 1L << 22,
        ImageAdExtensions = 1L << 23,
        CampaignImageAdExtensions = 1L << 24,
        AdGroupImageAdExtensions = 1L << 25,
        NegativeKeywordsList = 1L << 29,
        NegativeKeyword = 1L << 30,
        CampaignNegativeKeywordList = 1L << 31,
        AppAdExtensions = 1L << 32,
        CampaignAppAdExtensions = 1L << 33,
        AdGroupAppAdExtensions = 1L << 34,
        NewsAdExtensions = 1L << 35,
        CampaignNewsAdExtensions = 1L << 36,
        AdGroupNewsAdExtensions = 1L << 37,
        ReviewAdExtensions = 1L << 38,
        CampaignReviewAdExtensions = 1L << 39,
        AdGroupReviewAdExtensions = 1L << 40,
        DataTableAdExtensions = 1L << 41,
        CampaignDataTableAdExtensions = 1L << 42,
        AdGroupDataTableAdExtensions = 1L << 43
    }
}
