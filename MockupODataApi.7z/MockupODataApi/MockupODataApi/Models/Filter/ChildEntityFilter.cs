﻿namespace Microsoft.BingAds.Api.Model
{
    public class ChildEntityFilter :EntityFilter
    {
        public Operator CountOperator { get; set; }

        public int Count { get; set; }
    }    
}
