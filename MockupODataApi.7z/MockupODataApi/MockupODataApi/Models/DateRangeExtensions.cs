﻿namespace Microsoft.BingAds.Api.Model
{
    using System;
    using Microsoft.AdCenter.Advertiser.CampaignManagement.MT.Messages;

    public static class DateRangeExtensions
    {
        public static BiDateRange ToMtDateRange(this Model.DateRange dateRange, bool convertDateRangePresetToStartDateEndDate = false)
        {
            if (dateRange == null)
            {
                return null;
            }

            if (dateRange.StartDate.HasValue || dateRange.EndDate.HasValue)
            {
                return new BiDateRange
                {
                    Type = DateRangeType.CustomRange,
                    CustomDateRangeStart = (dateRange.StartDate == null)
                        ? null
                        : dateRange.StartDate.ToUtcDateTime(),
                    CustomDateRangeEnd = (dateRange.EndDate == null)
                        ? null
                        : dateRange.EndDate.ToUtcDateTime()
                };
            }
            if (dateRange.DateRangePreset.HasValue)
            {
                if (convertDateRangePresetToStartDateEndDate)
                {
                    DateTime? startDate;
                    DateTime? endDate;
                    dateRange.DateRangePreset.Value.ToMtDateRangeType().CalculateDateRange(DateTime.Today, out startDate, out endDate);
                    return new BiDateRange
                    {
                        Type = DateRangeType.CustomRange,
                        CustomDateRangeStart = startDate,
                        CustomDateRangeEnd = endDate
                    };
                }
                return new BiDateRange
                {
                    Type = dateRange.DateRangePreset.Value.ToMtDateRangeType(),
                    CustomDateRangeStart = null,
                    CustomDateRangeEnd = null
                };
            }
            return null;
        }

        public static DateRange ToApiDateRange(this BiDateRange dateRange)
        {
            if (dateRange == null)
            {
                return null;
            }

            // CustomDateRangeStart & CustomDateRangeEnd will take precedence over DateRangeType. If they exist we use that and ignore DateRangeType.
            if (dateRange.CustomDateRangeStart.HasValue || dateRange.CustomDateRangeEnd.HasValue)
            {
                return new DateRange
                {
                    DateRangePreset = null,
                    StartDate = dateRange.CustomDateRangeStart.ToUtcDateTimeOffset(),
                    EndDate = dateRange.CustomDateRangeEnd.ToUtcDateTimeOffset()
                };
            }
            if (dateRange.Type != DateRangeType.CustomRange)
            {
                return new DateRange
                {
                    DateRangePreset = dateRange.Type.ToApiDateRangePreset(),
                    StartDate = null,
                    EndDate = null
                };
            }
            return null;
        }
    }
}