﻿namespace Microsoft.AdCenter.Advertiser.CampaignManagement.MT.Messages
{
    using System;

    /// <summary>
    /// date ranges for BI data interval
    /// </summary>
    public enum DateRangeType // this is coming from Moonshot, keeping for backward compat with UI client
    {
        Yesterday = 1,
        Last7days = 2,
        Today = 3,
        CustomRange = 4,
        LastThirtyDays = 5,
        LastFourteenDays = 6,
        ThisMonth = 10,
        LastMonth = 11,
        Last3Months = 12,
        Last6Months = 13,
        Last12Months = 14,
        Last18Months = 15,
        ThisYear = 20,
        LastYear = 21,
        AllTime = 22,
        ThisWeekFromSun = 23,
        ThisWeekFromMon = 24,
        LastWeekStartingSun = 25,
        LastWeekStartingMon = 26,
        LastBusinessWeek = 27,
    }

    public static class DateRangeTypeExtension
    {
        ////refer to private\UI\CampaignUI\Src\CampaignWeb\Models\Shared\DateRangeItem.cs SetStartDateEndDate() to keep the same calculation logic
        public static void CalculateDateRange(this DateRangeType type, DateTime date, out DateTime? startDate, out DateTime? endDate)
        {
            startDate = null;
            endDate = null;
            int dayOfWeek = (int)date.DayOfWeek;
            
            switch (type)
            {
                case DateRangeType.Yesterday:
                    startDate = endDate = date.AddDays(-1);
                    break;
                case DateRangeType.Last7days:
                    endDate = date.AddDays(-1);
                    startDate = date.AddDays(-7);
                    break;
                case DateRangeType.Today:
                    startDate = endDate = date;
                    break;
                case DateRangeType.LastThirtyDays:
                    endDate = date.AddDays(-1);
                    startDate = date.AddDays(-30);
                    break;
                case DateRangeType.LastFourteenDays:
                    endDate = date.AddDays(-1);
                    startDate = date.AddDays(-14);
                    break;
                case DateRangeType.ThisMonth:
                    endDate = date;
                    startDate = GetFirstDayOfMonth(date);
                    break;
                case DateRangeType.LastMonth:
                    endDate = GetLastDayOfMonth(date.AddMonths(-1));
                    startDate = GetFirstDayOfMonth(date.AddMonths(-1));
                    break;
                case DateRangeType.Last3Months:
                    endDate = GetLastDayOfMonth(date.AddMonths(-1));
                    startDate = GetFirstDayOfMonth(date.AddMonths(-3));
                    break;
                case DateRangeType.Last6Months:
                    endDate = GetLastDayOfMonth(date.AddMonths(-1));
                    startDate = GetFirstDayOfMonth(date.AddMonths(-6));
                    break;
                case DateRangeType.Last12Months:
                    endDate = GetLastDayOfMonth(date.AddMonths(-1));
                    startDate = GetFirstDayOfMonth(date.AddMonths(-12));
                    break;
                case DateRangeType.Last18Months:
                    endDate = GetLastDayOfMonth(date.AddMonths(-1));
                    startDate = GetFirstDayOfMonth(date.AddMonths(-18));
                    break;
                case DateRangeType.ThisYear:
                    endDate = date;
                    startDate = GetFirstDayOfMonth(date.AddMonths(1 - date.Month));
                    break;
                case DateRangeType.LastYear:
                    endDate = GetLastDayOfMonth(date.AddMonths(-date.Month));
                    startDate = GetFirstDayOfMonth(date.AddYears(-1).AddMonths(1 - date.Month));
                    break;
                case DateRangeType.AllTime:
                    endDate = date;
                    startDate = date.AddYears(-2);
                    break;
                case DateRangeType.ThisWeekFromMon:
                    if (date.DayOfWeek == DayOfWeek.Sunday)
                    {
                        // If today is Sunday display last week
                        endDate = date.AddDays(-dayOfWeek);
                        startDate = date.AddDays(-dayOfWeek - 6);
                    }
                    else
                    {
                        endDate = date;
                        startDate = date.AddDays(-dayOfWeek + 1);
                    }

                    break;
                case DateRangeType.ThisWeekFromSun:
                    endDate = date;
                    startDate = date.AddDays(-dayOfWeek);
                    break;
                case DateRangeType.LastWeekStartingMon:
                    endDate = date.AddDays(-dayOfWeek);
                    startDate = date.AddDays(-dayOfWeek - 6);
                    break;
                case DateRangeType.LastWeekStartingSun:
                    endDate = date.AddDays(-dayOfWeek - 1);
                    startDate = date.AddDays(-dayOfWeek - 7);
                    break;
                case DateRangeType.LastBusinessWeek:
                    endDate = date.AddDays(-dayOfWeek - 2);
                    startDate = date.AddDays(-dayOfWeek - 6);
                    break;
                case DateRangeType.CustomRange:
                case 0: // Default value, not an option
                    break;
                default:
                    throw new ArgumentOutOfRangeException("type");
            }
        }

        private static DateTime GetLastDayOfMonth(DateTime dateTime)
        {
            return GetFirstDayOfMonth(dateTime).AddMonths(1).AddDays(-1);
        }

        private static DateTime GetFirstDayOfMonth(DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, 1);
        }
    }
}