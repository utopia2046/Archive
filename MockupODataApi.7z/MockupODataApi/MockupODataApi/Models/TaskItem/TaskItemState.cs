﻿namespace Microsoft.BingAds.TaskEngine.ObjectModel
{
    public enum TaskItemState
    {
        Deleted = 0,
        Active = 1,
        Paused = 2
    }
}
