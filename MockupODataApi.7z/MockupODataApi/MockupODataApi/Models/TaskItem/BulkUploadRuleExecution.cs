namespace Microsoft.BingAds.Api.Model
{
    using System.Collections.Generic;
    using Microsoft.BingAds.Api.Model.BulkUpload;

    public class BulkUploadRuleExecution : TaskItemExecution
    {
        public IEnumerable<KeyValuePair<string, BulkUploadEntityStatistics>> EntityStatsPerType { get; set; }
        public IEnumerable<BulkFile> BulkFiles { get; set; }
        public IEnumerable<KeyValuePair<long, IEnumerable<AdsApiError>>> ErrorsByAccountId { get; set; }
        public long RowsProcessed { get; set; }
        public long? TotalRows { get; set; }
        public string SessionId { get; set; }
    }
}