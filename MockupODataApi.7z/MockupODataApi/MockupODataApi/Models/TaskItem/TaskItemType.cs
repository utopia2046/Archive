﻿namespace Microsoft.BingAds.TaskEngine.ObjectModel
{
    public enum TaskItemType
    {
        ClickToCallProvisioning = 1,

        AdvertiserSearch = 2,

        Report =3,

        MultiAccountDownload = 4,

        MultiAccountUploadPreview = 5,

        MultiAccountUploadCommit = 6
    }
}
