﻿namespace Microsoft.BingAds.Api.Model
{
    using System;

    [Flags]
    public enum NotificationType : byte
    {
        None = 0,

        OnChange = 1,

        OnError = 2,

        Always = 255,
    }
}
