﻿namespace Microsoft.BingAds.Api.Model
{
    using System;

    public class AdvertiserRuleCheckPoint
    {
        public Guid BulkEditId { get; set; }
    }
}
