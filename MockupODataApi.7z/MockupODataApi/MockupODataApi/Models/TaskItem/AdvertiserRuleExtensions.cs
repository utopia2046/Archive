﻿namespace Microsoft.BingAds.Api.Model
{
    using V2;

    public static class AdvertiserRuleExtensions
    {
        public static BulkEditSession CreateBulkEditSession(this AdvertiserRule rule)
        {
            if (rule == null)
            {
                return null;
            }

            //if daterangepreset in Selection is set, no need to save DateRangePreset property into QueryString
            Selection selection;
            if (rule.Selection != null
                && rule.Selection.DateRange != null
                && rule.Selection.DateRange.DateRangePreset.HasValue)
            {
                selection = rule.Selection;
            }
            else
            {
                selection = rule.Selection == null ? new Selection() : rule.Selection.DeepClone();
                selection.QueryString = QueryStringUtility.Encode(selection.QueryString, rule.DateRangePreset);
            }

            return new BulkEditSession()
            {
                Id = string.Empty, // put dummy id here because oDataFormatSerializer needs it
                Entity = rule.Entity,
                BatchAction = rule.BatchAction,
                Selection = selection
            };
        }
    }
}
