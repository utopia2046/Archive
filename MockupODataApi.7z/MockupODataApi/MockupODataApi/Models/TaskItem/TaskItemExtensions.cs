﻿namespace Microsoft.BingAds.Api.Model
{   
    public static class TaskItemExtensions
    {
        public static TaskEngine.ObjectModel.TaskItem ToMtTaskItem(this TaskItem taskItem, int? customerId, long? accountId, int userId, string userName, string parameters)
        {
            if (taskItem == null)
            {
                return null;
            }

            TaskEngine.ObjectModel.NotificationType mtNotificationType;
            switch (taskItem.NotificationType)
            {
                case NotificationType.None:
                    mtNotificationType = TaskEngine.ObjectModel.NotificationType.None;
                    break;
                case NotificationType.OnError:
                    mtNotificationType = TaskEngine.ObjectModel.NotificationType.Errors;
                    break;
                case NotificationType.OnChange | NotificationType.OnError:
                    mtNotificationType = TaskEngine.ObjectModel.NotificationType.Changes | TaskEngine.ObjectModel.NotificationType.Errors;
                    break;
                case NotificationType.OnChange:
                    mtNotificationType = TaskEngine.ObjectModel.NotificationType.Changes;
                    break;
                default:
                    mtNotificationType = TaskEngine.ObjectModel.NotificationType.EveryTime;
                    break;
            }

            return new TaskEngine.ObjectModel.TaskItem()
            {
                Id = taskItem.Id,
                CustomerId = customerId.HasValue ? customerId.Value : - 1,
                AccountId = accountId.HasValue ? (int)accountId.Value : (int?)null,
                Name = taskItem.Name,
                TaskType = (int) taskItem.Type,
                ScheduleInfoCron = taskItem.Cron,
                UserId = userId,
                UserName = userName,
                Parameters = parameters,
                NotificationType = mtNotificationType,
                ScheduleInfoTimeZoneId = taskItem.TimeZoneId
            };
        }
    }
}
