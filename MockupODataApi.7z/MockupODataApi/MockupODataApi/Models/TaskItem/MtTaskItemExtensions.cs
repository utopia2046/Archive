﻿namespace Microsoft.BingAds.Api.Model
{
    using System;
    using Microsoft.BingAds.TaskEngine.ObjectModel;

    public static class MtTaskItemExtensions
    {
        public static TaskItem ToApiTaskItem(this TaskEngine.ObjectModel.TaskItem mtTaskItem,
            out string mtTaskItemParameters)
        {
            mtTaskItemParameters = null;

            if (mtTaskItem == null)
            {
                return null;
            }

            mtTaskItemParameters = mtTaskItem.Parameters;
            TaskItem apiTaskItem;
            if (mtTaskItem.TaskType == (int) TaskItemType.AdvertiserSearch)
            {
                apiTaskItem = new AdvertiserRule();
            }
            else if (mtTaskItem.TaskType == (int) TaskItemType.MultiAccountDownload)
            {
                apiTaskItem = new MultiAccountDownloadTaskItem();
            }
            else if (mtTaskItem.TaskType == (int)TaskItemType.Report)
            {
                apiTaskItem = new ReportRule();
            }
            else
            {
                throw new NotSupportedException("Unsupported task item type " + mtTaskItem.GetType());
            }
            PopulateBasicInfoFromTaskEngineToApi(apiTaskItem, mtTaskItem);
            return apiTaskItem;
        }

        private static void PopulateBasicInfoFromTaskEngineToApi(TaskItem dest, TaskEngine.ObjectModel.TaskItem source)
        {
            if (dest == null || source == null)
            {
                return;
            }

            NotificationType notificationType;
            switch (source.NotificationType)
            {
                case TaskEngine.ObjectModel.NotificationType.Errors:
                    notificationType = NotificationType.OnError;
                    break;
                case TaskEngine.ObjectModel.NotificationType.Changes | TaskEngine.ObjectModel.NotificationType.Errors:
                    notificationType = NotificationType.OnChange | NotificationType.OnError;
                    break;
                case TaskEngine.ObjectModel.NotificationType.None:
                    notificationType = NotificationType.None;
                    break;
                default:
                    notificationType = NotificationType.Always;
                    break;
            }

            dest.Cron = source.ScheduleInfoCron;
            dest.Id = source.Id;
            dest.ModifiedAt = source.CreatedTimeUTc.ToUtcDateTimeOffset();
            dest.ModifiedBy = new User() {Id = source.UserId, Name = source.UserName};
            dest.Name = source.Name;
            dest.NotificationMedium = NotificationMedium.Email;
            dest.NotificationType = notificationType;
            dest.State = source.Status;
            dest.Type = (TaskItemType) source.TaskType;
            dest.TimeZoneId = source.ScheduleInfoTimeZoneId;
        }
    
    }
}
