﻿namespace Microsoft.BingAds.Api.Model
{
    using V2;

    public class AdvertiserRule : TaskItem
    {
        public string Entity { get; set; }

        public Selection Selection { get; set; }

        public BulkEditBatchAction BatchAction { get; set; }

        public string Description { get; set; }

        public DateRangePreset DateRangePreset { get; set; }
    }
}
