﻿namespace Microsoft.BingAds.Api.Model
{
    using System;

    [Flags]
    public enum NotificationMedium
    {
        Email = 1
    }
}
