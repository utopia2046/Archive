﻿namespace Microsoft.BingAds.Api.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using Microsoft.BingAds.TaskEngine.ObjectModel;
    
    //[VersionRange(2)]
    public abstract class TaskItem
    {
        [Key]
        public long Id { get; set; }
        public string Name { get; set; }
        public TaskItemType Type { get; set; }
        public TaskItemState State { get; set; }

        public string Cron { get; set; }
        public NotificationType NotificationType { get; set; }
        public NotificationMedium NotificationMedium { get; set; }
        
        public User ModifiedBy { get; set; }
        public DateTimeOffset? ModifiedAt { get; set; }
        
        public int? TimeZoneId { get; set; }

        public IEnumerable<TaskItemExecution> TaskItemExecutions { get; set; }
    }
}
