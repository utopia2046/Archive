﻿namespace Microsoft.BingAds.Api.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using Microsoft.BingAds.TaskEngine.ObjectModel;


    [VersionRange(2)]
    public class TaskItemExecution
    {
        [Key]
        public long Id { get; set; }
        public RunResultState Status { get; set; }
        public DateTimeOffset StartedAt { get; set; }
        public int? TimeSpan { get; set; }
        public string ResultId { get; set; }
        
        public TaskItem TaskItem { get; set; }
        public int SuccessCount { get; set; }
        public int ErrorCount { get; set; }

        // leave it here as workaround to support UI filtering "success>0 or error>0" because of the limitation of UI infra to build filters on multiple fields
        public long? TotalCount { get; set; }
    }
}
