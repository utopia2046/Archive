﻿namespace Microsoft.BingAds.Api.Model
{
    using Newtonsoft.Json;

    public class TaskItemParameters
    {
        //plug-in will pick this and send to correspoding service to trigger task item execution
        public string Payload { get; set; }

        //the version number in which task item is saved as
        public string Version { get; set; }

        //store anything for special requirements, for example, for AdvertiserRule, it will be BulkEdit's Description field which is used by UI for rendering filters
        public string PlaceHolder { get; set; }

        public string Serialize()
        {
            return JsonConvert.SerializeObject(this);
        }

        public T DeserializePayload<T>()
        {
            if (Payload == null)
            {
                return default(T);
            }

            return JsonConvert.DeserializeObject<T>(
                Payload,
                new JsonSerializerSettings
                {
                    TypeNameHandling = TypeNameHandling.Auto
                });
        }
    }
}
