﻿namespace Microsoft.BingAds.Api.Model
{
    using System;
    using Microsoft.AdCenter.Advertiser.CampaignManagement.MT.Messages;

    public enum DateRangePreset
    {
        Yesterday = 1,
        LastSevenDays = 2,
        Today = 3,
        LastThirtyDays = 4,
        LastFourteenDays = 5,
        ThisMonth = 6,
        LastMonth = 7,
        LastThreeMonths = 8,
        LastSixMonths = 9,
        ThisYear = 10,
        LastYear = 11,
        AllTime = 12,
        ThisWeekFromSun = 13,
        ThisWeekFromMon = 14,
        LastWeekStartingSun = 15,
        LastWeekStartingMon = 16,
        LastBusinessWeek = 17,
    }

    public static class DateRangePresetExtensions
    {
        public static DateRangeType ToMtDateRangeType(this DateRangePreset dateRangePreset)
        {
            switch (dateRangePreset)
            {
                case DateRangePreset.Yesterday: 
                    return DateRangeType.Yesterday;
                case DateRangePreset.LastSevenDays:
                    return DateRangeType.Last7days;
                case DateRangePreset.Today:
                    return DateRangeType.Today;
                case DateRangePreset.LastThirtyDays:
                    return DateRangeType.LastThirtyDays;
                case DateRangePreset.LastFourteenDays:
                    return DateRangeType.LastFourteenDays;
                case DateRangePreset.ThisMonth:
                    return DateRangeType.ThisMonth;
                case DateRangePreset.LastMonth:
                    return DateRangeType.LastMonth;
                case DateRangePreset.LastThreeMonths:
                    return DateRangeType.Last3Months;
                case DateRangePreset.LastSixMonths:
                    return DateRangeType.Last6Months;
                case DateRangePreset.ThisYear:
                    return DateRangeType.ThisYear;
                case DateRangePreset.LastYear:
                    return DateRangeType.LastYear;
                case DateRangePreset.AllTime:
                    return DateRangeType.AllTime;
                case DateRangePreset.ThisWeekFromMon:
                    return DateRangeType.ThisWeekFromMon;
                case DateRangePreset.ThisWeekFromSun:
                    return DateRangeType.ThisWeekFromSun;
                case DateRangePreset.LastWeekStartingMon:
                    return DateRangeType.LastWeekStartingMon;
                case DateRangePreset.LastWeekStartingSun:
                    return DateRangeType.LastWeekStartingSun;
                case DateRangePreset.LastBusinessWeek:
                    return DateRangeType.LastBusinessWeek;
                default:
                    throw new ArgumentOutOfRangeException("dateRangePreset");
            }
        }

        public static DateRangePreset ToApiDateRangePreset(this DateRangeType dateRangeType)
        {
            switch (dateRangeType)
            {
                case DateRangeType.Yesterday:
                    return DateRangePreset.Yesterday;
                case DateRangeType.Last7days:
                    return DateRangePreset.LastSevenDays;
                case DateRangeType.Today:
                    return DateRangePreset.Today;
                case DateRangeType.LastThirtyDays:
                    return DateRangePreset.LastThirtyDays;
                case DateRangeType.LastFourteenDays:
                    return DateRangePreset.LastFourteenDays;
                case DateRangeType.ThisMonth:
                    return DateRangePreset.ThisMonth;
                case DateRangeType.LastMonth:
                    return DateRangePreset.LastMonth;
                case DateRangeType.Last3Months:
                    return DateRangePreset.LastThreeMonths;
                case DateRangeType.Last6Months:
                    return DateRangePreset.LastSixMonths;
                case DateRangeType.ThisYear:
                    return DateRangePreset.ThisYear;
                case DateRangeType.LastYear:
                    return DateRangePreset.LastYear;
                case DateRangeType.AllTime:
                    return DateRangePreset.AllTime;
                case DateRangeType.ThisWeekFromMon:
                    return DateRangePreset.ThisWeekFromMon;
                case DateRangeType.ThisWeekFromSun:
                    return DateRangePreset.ThisWeekFromSun;
                case DateRangeType.LastWeekStartingMon:
                    return DateRangePreset.LastWeekStartingMon;
                case DateRangeType.LastWeekStartingSun:
                    return DateRangePreset.LastWeekStartingSun;
                case DateRangeType.LastBusinessWeek:
                    return DateRangePreset.LastBusinessWeek;
                case DateRangeType.Last18Months:
                case DateRangeType.Last12Months:
                case DateRangeType.CustomRange:
                default:
                    throw new ArgumentOutOfRangeException("dateRangeType");
            }
        }
    }

}
