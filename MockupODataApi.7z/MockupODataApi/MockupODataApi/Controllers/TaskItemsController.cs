﻿using System.Web.OData.Results;
using Microsoft.BingAds.Api.Model;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
using MockupODataApi.Models;

namespace MockupODataApi.Controllers
{
    public class TaskItemsController : ODataController
    {
        MockupODataApiDbContext db = new MockupODataApiDbContext();

        private bool TaskItemExists(int key)
        {
            return db.TaskItems.Any(t => t.Id == key);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
 	        base.Dispose(disposing);
        }

        [EnableQuery]
        public IQueryable<MultiAccountDownloadTaskItem> Get()
        {
            return db.TaskItems;
        }

        [EnableQuery]
        public SingleResult<MultiAccountDownloadTaskItem> Get([FromODataUri] int key)
        {
            IQueryable<MultiAccountDownloadTaskItem> result = db.TaskItems.Where(p => p.Id == key);
            return SingleResult.Create(result);
        }

        public async Task<IHttpActionResult> Post(MultiAccountDownloadTaskItem taskItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.TaskItems.Add(taskItem);
            await db.SaveChangesAsync();
            return Created(taskItem);
        }

        public async Task<IHttpActionResult> Patch([FromODataUri] int key, Delta<MultiAccountDownloadTaskItem> taskItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.TaskItems.FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }
            taskItem.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TaskItemExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int key, MultiAccountDownloadTaskItem update)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (key != update.Id)
            {
                return BadRequest();
            }
            db.Entry(update).State = EntityState.Modified;
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TaskItemExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(update);
        }

        public async Task<IHttpActionResult> Delete([FromODataUri] int key)
        {
            var taskItem = await db.TaskItems.FindAsync(key);
            if (taskItem == null)
            {
                return NotFound();
            }
            db.TaskItems.Remove(taskItem);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}