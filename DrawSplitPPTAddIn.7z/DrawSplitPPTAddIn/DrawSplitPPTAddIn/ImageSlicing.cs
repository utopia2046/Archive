﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using AForge.Imaging;
using AForge.Imaging.Filters;

namespace DrawSplitPPTAddIn
{
    public class Sprite
    {
        public Bitmap Image { get; set; }
        public string FilePath { get; set; }
        public int Left { get; set; }
        public int Top { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }

    public class ImageSlicing
    {
        public static Bitmap LoadBitmap(string fileName)
        {
            try
            {
                return AForge.Imaging.Image.FromFile(fileName);

            }
            catch (Exception)
            {
                return null;
            }
        }

        public static void SaveBitmap(string fileName, Bitmap bitmap)
        {
            bitmap.Save(fileName);
        }

        public static Bitmap RemoveBackground(Bitmap input)
        {
            // Convert input image to greyscale
            Grayscale grayFilter = Grayscale.CommonAlgorithms.BT709;
            Bitmap grayImage = grayFilter.Apply(input);

            // Create iterative threshold filter
            IterativeThreshold filter = new IterativeThreshold(64, 128);
            Bitmap binaryImage = filter.Apply(grayImage);

            return binaryImage;
        }

        public static Sprite[] ExtractSubimages(Bitmap original, Bitmap binaryBitmap)
        {
            BlobCounter blobCounter = new BlobCounter
            {
                FilterBlobs = true,
                CoupledSizeFiltering = true,
                MinHeight = 5,
                MinWidth = 5
            };

            // Blob counter takes a black background picture while our painting is on white, so we invert it
            Invert invertFilter = new Invert();
            Bitmap invertBinary = invertFilter.Apply(binaryBitmap);

            // Dilatation the bitmap to reduce small clips
            Dilatation dilatationFilter = new Dilatation();
            dilatationFilter.Apply(invertBinary);

            blobCounter.ProcessImage(invertBinary);

            Blob[] blobs = blobCounter.GetObjectsInformation();
            int count = blobs.Length;
            if (count > 0)
            {
                string tempFolder = Path.GetTempPath();
                Sprite[] spriteArray = new Sprite[count];
                for (int i = 0; i < count; i++)
                {
                    blobCounter.ExtractBlobsImage(original, blobs[i], false);
                    blobs[i].Image.MakeTransparent();
                    string path = tempFolder + String.Format("tempImage_{0}.png", i);
                    blobs[i].Image.Save(path, ImageFormat.Png);
                    Sprite sprite = new Sprite()
                    {
                        Image = blobs[i].Image,
                        FilePath = path,
                        Height = blobs[i].Rectangle.Height,
                        Width = blobs[i].Rectangle.Width,
                        Left = blobs[i].Rectangle.Left,
                        Top = blobs[i].Rectangle.Top
                    };
                    spriteArray[i] = sprite;
                }
                return spriteArray;
            }
            return null;
        }
    }
}
