﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Microsoft.Office.Tools.Ribbon;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;

namespace DrawSplitPPTAddIn
{
    public partial class Ribbon1
    {
        private PowerPoint.Application _app;
        private PowerPoint.Presentation _ppt;
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            try
            {
                _app = Globals.ThisAddIn.Application;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to load Add-in: " + ex.Message);
            }
        }

        private void btnInsertImage_Click(object sender, RibbonControlEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "All pictures (*.jpg,*.jpeg,*.png,*.bmp,*.gif,*.tif)|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif|" +
              "All files (*.*)|*.*";

            dialog.CheckFileExists = true;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Bitmap source = ImageSlicing.LoadBitmap(dialog.FileName);
                Sprite binary = RemoveBackground(source, dialog.FileName);
                AddPicture(binary.FilePath);
                AddSprites(source, binary.Image);
            }
        }

        private const string TempFileExt = "_processed";
        private Sprite RemoveBackground(Bitmap source, string sourcePath)
        {
            Sprite binaryImage = new Sprite();
            binaryImage.FilePath = GetTempFilename(sourcePath);
            binaryImage.Image = ImageSlicing.RemoveBackground(source);
            ImageSlicing.SaveBitmap(binaryImage.FilePath, binaryImage.Image);
            return binaryImage;
        }

        private string GetTempFilename(string fileName)
        {
            string folder = Path.GetDirectoryName(fileName);
            string ext = Path.GetExtension(fileName);
            string tempFileName = Path.GetTempPath() + Path.GetFileNameWithoutExtension(fileName) + TempFileExt + ext;
            return tempFileName;
        }

        private void AddSprites(Bitmap sourceImage, Bitmap binaryImage)
        {
            Sprite[] sprites = ImageSlicing.ExtractSubimages(sourceImage, binaryImage);
            if ((sprites == null) || (sprites.Length < 1) || (_app == null))
            {
                return;
            }
            _ppt = _app.ActivePresentation;
            if (_ppt == null)
            {
                return;
            }
            PowerPoint.Slide slide = _ppt.Slides.Add(_ppt.Slides.Count + 1,
                PowerPoint.PpSlideLayout.ppLayoutBlank);
            float scale = GetPixel2PointScale();
            foreach (var sprite in sprites)
            {

                slide.Shapes.AddPicture(sprite.FilePath, MsoTriState.msoFalse, MsoTriState.msoTrue,
                    scale * sprite.Left, scale * sprite.Top);
            }
            slide.Select();
        }

        // TODO: convert pixel to point, it depends on the slide's size and current monitor DPI
        // For example, by default a blank slide is 1280x720, 13.3333x7.5 inches = 96 pixels/inch
        // A point is 1/72 inch, 96/72 = 1.3333
        // and when current display is 125%, 1 / (1.3333*1.25) = 0.6
        // So far I hardcode it for prototype
        private float GetPixel2PointScale()
        {
            return 0.6f;
        }

        private void AddPicture(string picFilename)
        {
            try
            {
                _ppt = _app.ActivePresentation;
                if (_ppt != null)
                {
                    PowerPoint.Slide slide = _ppt.Slides.Add(_ppt.Slides.Count + 1,
                        PowerPoint.PpSlideLayout.ppLayoutBlank);
                    slide.Shapes.AddPicture2(picFilename, MsoTriState.msoFalse, MsoTriState.msoTrue, 0, 0);
                    slide.Select();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to insert selected picture: " + ex.Message);
            }
        }
    }
}
