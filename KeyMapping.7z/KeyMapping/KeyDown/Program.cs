﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyDown
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press Esc to quit");
            ConsoleKeyInfo keyInfo = Console.ReadKey();
            while (keyInfo.Key != ConsoleKey.Escape)
            {
                Console.WriteLine("Key = {0}; \t KeyChar = {1}; \t Modifier = {2}", keyInfo.Key, keyInfo.KeyChar, keyInfo.Modifiers);
                keyInfo = Console.ReadKey();
            }
        }
    }
}
