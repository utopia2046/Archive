﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComicDownloader
{
    class Program
    {
        const string DefaultSiteRoot = "http://www.tuku.cc/comic/";

        static string url = String.Empty;
        static string comicId = String.Empty;
        static string volumnId = String.Empty;

        static void Main(string[] args)
        {
            if (!ParseArguments(args))
            {
                return;
            }

            var siteRoot = Properties.Settings.Default.SiteRoot;
            if (String.IsNullOrEmpty(siteRoot))
            {
                ShowWarning();
                siteRoot = DefaultSiteRoot;
            }

            var localPath = Properties.Settings.Default.LocalPath;
            if (!Directory.Exists(localPath))
            {
                ShowWarning();
                localPath = Directory.GetCurrentDirectory();
            }

            var grabber = new Grabber(siteRoot, localPath);

            if (String.IsNullOrEmpty(url))
            {
                grabber.DownloadFromId(comicId, volumnId);
            }
            else
            {
                grabber.DownloadFromUrl(url);
            }
        }

        static bool ParseArguments(string[] args)
        {
            if (args.Count() < 1)
            {
                ShowHelp();
                return false;
            }
            else if (args.Count() == 1)
            {
                if (!Grabber.IsValidComicAddress(args[0]))
                {
                    ShowHelp();
                    return false;
                }
                url = args[0];
                return true;
            }
            else
            {
                comicId = args[0];
                volumnId = args[1];
                return true;
            }
        }

        static void ShowHelp()
        {
            Console.WriteLine("");
            Console.WriteLine("Usage:");
            Console.WriteLine("  ComicDownloader <comic_id> <volumn_id>");
            Console.WriteLine("or");
            Console.WriteLine("  ComicDownloader <url>");
            Console.WriteLine("");
            Console.WriteLine("<id> is the comic book id. Or <url> is the comic book url.");
            Console.WriteLine("");
            Console.WriteLine("Example:");
            Console.WriteLine("  ComicDownloader 20476 n-1461143105-64600");
            Console.WriteLine("  ComicDownloader http://www.tuku.cc/comic/20476/n-1461143105-64600/");
            Console.WriteLine("  ComicDownloader 11285 2");
            Console.WriteLine("  ComicDownloader http://www.tuku.cc/comic/11285/2/");
            Console.WriteLine("");
        }

        static void ShowWarning()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("config file is damaged.");
            Console.ResetColor();
        }
    }
}
