﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace ComicDownloader
{
    class Grabber
    {
        const string UserAgent = @"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36";
        string siteRoot;
        string localPath;
        int maxRetry = 0;
        int maxSleepTimeInMs = 3000;
        //WebClient client;

        public Grabber(string siteRoot, string localPath)
        {
            this.siteRoot = siteRoot;
            this.localPath = localPath;
            //client = new WebClient();
            maxRetry = Properties.Settings.Default.MaxiumRetry;
        }

        public static bool IsValidComicAddress(string url)
        {
            Uri uri;
            return Uri.TryCreate(url, UriKind.Absolute, out uri) && ( (uri.Scheme == Uri.UriSchemeHttp) || (uri.Scheme == Uri.UriSchemeHttps));
        }

        public bool DownloadFromId(string comicId, string volumnId)
        {
            return false;
        }

        public bool DownloadFromUrl(string url)
        {
            var html = GetPageHtml(url);
            return false;
        }

        private Tuple<int, string> GetImageUrls(string html)
        {
            var doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(html);

            if ( (doc.ParseErrors != null && doc.ParseErrors.Count() > 0) || (doc.DocumentNode == null))
            {
                //
                return null;
            }
            else
            {
                var url = doc.DocumentNode.SelectSingleNode("//img").InnerText;
                var countString = doc.DocumentNode.SelectSingleNode("").InnerText;
                int count;
                Int32.TryParse(countString, out count);
                return new Tuple<int, string>(count, url);
            }
        }

        private string GetPageHtml(string url)
        {
            //var stream = client.OpenRead(url);
            //stream.Close();
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.UserAgent = UserAgent;
            request.Method = "GET";
            request.Timeout = 20000;
            WebResponse response = null;

            var retry = maxRetry;
            var isSuccess = false;

            while (retry > 0)
            {
                response = request.GetResponse();
                switch (((HttpWebResponse)response).StatusCode)
                {
                    case HttpStatusCode.OK:
                        retry = 0;
                        isSuccess = true;
                        break;
                    case HttpStatusCode.NotFound:
                        retry = 0;
                        // output
                        break;
                    default:
                        //output
                        WaitForRandomTime();
                        retry--;
                        break;
                }
            }

            if (isSuccess && (response != null))
            {
                using (var stream = response.GetResponseStream())
                using (var reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }

            return String.Empty;
        }

        private void WaitForRandomTime()
        {
            var random = new Random();
            Thread.Sleep(random.Next(0, maxSleepTimeInMs));
        }

        private void DownloadFile(string url, string localPath)
        {
            using (var client = new WebClient())
            {
                //byte[] data = client.DownloadData(new Uri(url));
                //using (var stream = new MemoryStream(data))
                //using (var image = Image.FromStream(stream))
                //{
                //    var format = image.RawFormat;
                //    image.Save(stream, format);
                //}
                client.DownloadFile(new Uri(url), localPath);
            }
        }

        private static void DownloadRemoteImageFile(string uri, string fileName)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (Exception)
            {
                // output
                return;
            }

            // Check that the remote file was found. The ContentType
            // check is performed since a request for a non-existent
            // image file might be redirected to a 404-page, which would
            // yield the StatusCode "OK", even though the image was not
            // found.
            if ((response.StatusCode == HttpStatusCode.OK ||
                response.StatusCode == HttpStatusCode.Moved ||
                response.StatusCode == HttpStatusCode.Redirect) &&
                response.ContentType.StartsWith("image", StringComparison.OrdinalIgnoreCase))
            {

                // if the remote file was found, download oit
                using (Stream inputStream = response.GetResponseStream())
                using (Stream outputStream = File.OpenWrite(fileName))
                {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    do
                    {
                        bytesRead = inputStream.Read(buffer, 0, buffer.Length);
                        outputStream.Write(buffer, 0, bytesRead);
                    } while (bytesRead != 0);
                }
            }
        }
    }
}
